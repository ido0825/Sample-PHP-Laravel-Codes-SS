
@extends('mainpage')

@section('htmlheader_title')
  DTR-Payslip
@endsection

@section('main-content')

<style type="text/css">
  .dropzone {
     min-height: 0px; 
     border: 0px solid #e5e5e5; 
}

.dz-error-mark { display: none; }

.dz-success-mark { display: none; }
.dz-image { display: none; }

.dz-size { display: none; }

.dropzone .dz-preview.dz-success .dz-success-mark { display: none; }
o
.dropzone .dz-preview.dz-error .dz-error-message, .dropzone .dz-preview.dz-error .dz-error-mark { display: none; }

</style>

<section class="content">

  <div class="clearfix"></div>

  <div class="row">



    <input type="hidden" name="_token" value="{{ csrf_token() }}">

    <div class="col-md-12 col-sm-12 col-xs-12" id="mainpagediv">

      <div class="x_panel">

        <div class="x_title">

          <div class="col-md-6 col-sm-6 col-xs-12">

          <h2>Payroll</h2>  

          </div>

          <div class="col-md-6 col-sm-6 col-xs-12" style="text-align: right;">
          </div>

          <div class="clearfix"></div>

        </div>

        <div class="x_content">

          

          <div class="col-md-12 col-sm-12 col-xs-12" style="">

           
           <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="col-md-12 col-sm-12 col-xs-12">
                   <div class="col-md-12 col-sm-12 col-xs-12"> <p style="margin: 0px;">Month:</p></div>
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        <select class="form-control" id="emonth" style="width: 100%;">
                      <option value="1">January</option>
                    <option value="2">Febuary</option>
                    <option value="3">March</option>
                    <option value="4">April</option>
                    <option value="5">May</option>
                    <option value="6">June</option>
                    <option value="7">July</option>
                    <option value="8">August</option>
                    <option value="9">September</option>
                    <option value="10">October</option>
                    <option value="11">November</option>
                    <option value="12">December</option>

                    </select>

                  </div>

                </div>

           </div>



           <div class="col-md-3 col-sm-6 col-xs-12">

              <div class="col-md-12 col-sm-12 col-xs-12">

                   <div class="col-md-12 col-sm-12 col-xs-12"> <p style="margin: 0px;">Cut-Off:</p></div>

                      <div class="col-md-12 col-sm-12 col-xs-12">

                        <select class="form-control" id="ecutoff" style="width: 100%;">

                      <option selected="selected" value="0">01-15</option>

                    <option value="1">16-31</option>

                    </select>

                  </div>

                </div>

           </div>



           <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="col-md-12 col-sm-12 col-xs-12">
                   <div class="col-md-12 col-sm-12 col-xs-12"> <p style="margin: 0px;">Year:</p></div>
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        <select class="form-control" id="eyear">
                      <option value="2025">2025</option>
                    <option value="2024">2024</option>
                    <option value="2023">2023</option>
                    <option value="2022">2022</option>
                    <option value="2021">2021</option>
                    <option value="2020">2020</option>
                    <option value="2019">2019</option>
                    </select>
                  </div>
                </div>
           </div>


           <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="col-md-12 col-sm-12 col-xs-12">
                   <div class="col-md-12 col-sm-12 col-xs-12"> <p style="margin: 0px;font-weight: bold;">BOU:</p></div>
                      <div class="col-md-12 col-sm-12 col-xs-12">
                        <select class="form-control" id="ebou">
                      <option value="2025">Loading ...</option>
                    </select>
                  </div>
                </div>
           </div>



          </div>

          <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px; text-align: center;">
            <button class="btn btn-success btn-sm" style="font-size: 12px;" id="searchdtr"><i class="fa fa-search"></i> SEARCH</button>
          </div>


          <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 30px; padding-left: 2%; display: ;">
            <button class="btn btn-default btn-sm" id="processdtrtop"  style="font-size: 10px;background: #b6d5da;color: #1372b9;"><img src="../images/process.png" width="25" height="25"> PROCESS ALL</button>
             <button class="btn btn-default btn-sm" id="reprocessdtrtop" style="font-size: 10px;background: #b6d5da;color: #1372b9;"><img src="../images/reprocess.jpg" width="25" height="25"> RE-PROCESS ALL</button>
          </div>


          <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 5px;">

          

         <table id="payrolltbl" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th style="text-align: center;padding: 2px;background: aliceblue;"></th>
                          <th style="text-align: center;padding: 2px;background: aliceblue;">EMPLOYEE</th>
                          <th style="text-align: center;padding: 2px;background: aliceblue;">CUT-OFF</th>
                          <th style="text-align: center;padding: 2px;background: aliceblue;">PAYOUT</th>
                          <th style="text-align: center;padding: 2px;background: aliceblue;">PAYSLIP #</th>
<!--                           <th style="text-align: center;padding: 2px;background: aliceblue;">EMAIL</th> -->

                        </tr>
                      </thead>
                    </table>
                    </div>
        </div>
      </div>
    </div> <!-- div of page -->

    <div class="col-md-12 col-sm-12 col-xs-12" id="loaderpage" style="text-align: center;position: absolute;top: 50%; display: none;    left: 8%;">
    <img src="../images/Spin-1s-137px.gif" class="ajax-loader">
  </div>
  

  </div>

</section>







<!-- Modal -->

  <div class="modal fade" id="myModal" role="dialog">

    <div class="modal-dialog modal-lg" style="max-width: 85%;">  <!-- style="max-width: 50% !important;" -->

      <div class="modal-content">

        <div class="modal-header">

          <div class="col-md-6 col-sm-6 col-xs-12">

          <h5 class="modal-title" id="ps_name"></h5> <input type="hidden" id="ps_empnum">

          <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->

        </div>

         <div class="col-md-6 col-sm-6 col-xs-12" style="text-align: right;">

          <div class="btn-group">
          <!-- <button class="btn btn-warning btn-sm" style="font-size: 12px;"><i class="fa fa-refresh"></i> Re-Process</button> -->
          <button class="btn btn-default btn-sm" style="font-size: 12px;background: #007bff;color: #fff;" id="ps_btnemail_it" disabled="disabled"><i class="fa fa-mail-forward"></i> <i class="fa fa-user"></i> Email Payslip</button>
          <button class="btn btn-default btn-sm" style="font-size: 12px;border: 1px solid red;color: red;" id="dl_ps_pdf" disabled="disabled"><i class="fa fa-file-pdf-o"></i> Download</button>
          <input type="hidden" id="psid">
          <input type="hidden" id="eid">
          </div>

        </div>

        </div>

        <div class="modal-body">

          <div class="col-md-12 col-sm-12 col-xs-12" style="background: #eaf7f9;padding: 5px;display: none;" id="div_ps_email_confirm_div">
            <div class="col-md-8 col-sm-8 col-xs-12" style="text-align: center;">
            <label style="color: #c56161;">Please confirm employee email: <span style="font-weight: normal;" id="payslip_email_pdf"></span></label>
          </div>
          <div class="col-md-4 col-sm-4 col-xs-6">
             <div class="btn-group">
            <button class="btn btn-default btn-sm" style="font-size: 10px;background: #dae7f3;" id="ps_confirm_email"><i class="fa fa-send-o"></i> SEND PAYSLIP</button>
            <button class="btn btn-default btn-sm" style="font-size: 10px;background: gray;color: #fff;" id="payslip_email_cancel"><i class="fa fa-remove"></i> CANCEL</button>
          </div></div>
          </div>

          <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px;">



          <div class="col-md-12 col-sm-12 col-xs-12" id="payslip_div">



            <div class="col-md-12 col-sm-12 col-xs-12" style="border: 1px solid gray; border-radius: 3px;">



              <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px;">

                

                <div class="col-md-6 col-sm-6 col-xs-12">

                <div class="col-md-2 col-sm-3 col-xs-12" style="">

                <img src="../images/atomit.png" alt="logo" width="40" height="40">

              </div>

              <div class="col-md-10 col-sm-9 col-xs-12" style="">

                <h5 style="font-size: 15px; margin-top: 4%; color: #17a2b8; font-weight: bold;">ATOMIT BUSINESS SOLUTION CORP.</h5>

              </div>

            </div>



            <div class="col-md-6 col-sm-6 col-xs-12">

              <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: right;">

                <h5 style="font-size: 20px; margin-top: 2%; color: #17a2b8; font-weight: bold;margin-bottom: 0px;">PAYSLIP</h5>

                <p style="margin: 0px;font-size: 12px;">PERIOD: <span id="ps_period"></span></p>

              </div>

            </div>



              </div>



              <!-- employee detail -->

              <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px;">

                <div class="col-md-6 col-sm-6 col-xs-6">



                  <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="col-md-4 col-sm-5 col-xs-6"> <label style="font-size: 12px;margin-bottom: 0px;">Employee ID:</label> </div>

                    <div class="col-md-8 col-sm-7 col-xs-6"> <p style="margin-bottom: 0px;" id="ps_eid"></p> </div>

                  </div>



                 <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="col-md-4 col-sm-5 col-xs-6"> <label style="font-size: 12px;margin-bottom: 0px;">Department:</label> </div>

                    <div class="col-md-8 col-sm-7 col-xs-6"> <p style="margin-bottom: 0px;" id="ps_department"></p> </div>

                  </div>



                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="col-md-4 col-sm-5 col-xs-6"> <label style="font-size: 12px;margin-bottom: 0px;">TIN No. :</label> </div>

                    <div class="col-md-8 col-sm-7 col-xs-6"> <p style="margin-bottom: 0px;" id="ps_tinno"></p> </div>

                  </div>



                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="col-md-4 col-sm-5 col-xs-6"> <label style="font-size: 12px;margin-bottom: 0px;">Tax Code:</label> </div>

                    <div class="col-md-8 col-sm-7 col-xs-6"> <p style="margin-bottom: 0px;" id="ps_taxcode"></p> </div>

                  </div>



                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="col-md-4 col-sm-5 col-xs-6"> <label style="font-size: 12px;margin-bottom: 0px;">Emp Status:</label> </div>

                    <div class="col-md-8 col-sm-7 col-xs-6"> <p style="margin-bottom: 0px;" id="ps_estat"></p> </div>

                  </div>



                </div>



                <div class="col-md-6 col-sm-6 col-xs-6">

                  

                  <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="col-md-4 col-sm-5 col-xs-6"> <label style="font-size: 12px;margin-bottom: 0px;">Employee:</label> </div>

                    <div class="col-md-8 col-sm-7 col-xs-6"> <p style="margin-bottom: 0px;" id="ps_ename"></p> </div>

                  </div>



                  <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="col-md-4 col-sm-5 col-xs-6"> <label style="font-size: 12px;margin-bottom: 0px;">Designation:</label> </div>

                    <div class="col-md-8 col-sm-7 col-xs-6"> <p style="margin-bottom: 0px;" id="ps_jobt"></p> </div>

                  </div>



                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="col-md-4 col-sm-5 col-xs-6"> <label style="font-size: 12px;margin-bottom: 0px;">Pay Date:</label> </div>

                    <div class="col-md-8 col-sm-7 col-xs-6"> <p style="margin-bottom: 0px;" id="ps_paydate"></p> </div>

                  </div>



                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="col-md-4 col-sm-5 col-xs-6"> <label style="font-size: 12px;margin-bottom: 0px;">Payslip No. :</label> </div>

                    <div class="col-md-8 col-sm-7 col-xs-6"> <p style="margin-bottom: 0px;" id="ps_psno"></p> </div>

                  </div>



                </div>

              </div>





              <!-- earning -->

              <div class="col-md-6 col-sm-6 col-xs-12" style="margin-top: 10px;">

                
                <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: right;padding: 0px;">
                <button class="btn btn-warning btn-sm" style="font-size: 8px; color: #fff;" id="btnoverride_earnings"><i class="fa fa-exclamation"></i> OVERRIDE</button>
                <div class="btn-group" id="btnoverride_earning_savediv" style="display: none;padding: 1px;">
                   <button class="btn btn-success btn-sm" style="font-size: 8px; color: #fff;" id="btnsave_earnings">UPDATE</button>
                    <button class="btn btn-default btn-sm" style="background: gray; font-size: 8px; color: #fff;" id="btncancel_earnings">CANCEL</button>
                </div> </div>


                 <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0px; margin-top: 3px;">

                   <table id="" class="table table-bordered" style="width:100%; font-size: 12px;padding: 0px;">

                     <thead><tr>

                  <th colspan="4" style="vertical-align: middle;padding: 0px 0px 0px 0px;text-align: center;"> EARNINGS</th></tr></thead>

                  <thead><tr>

                    <td style="text-align: center;vertical-align: middle;padding: 0px;width: 150px;"></td>
                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;">YTD</td>
                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;">HRS</td>
                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;">AMOUNT</td>

                  </tr></thead>

                  <tbody>

                    <tr>

                      <td style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Basic Pay</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_bpay_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;"></td>
                      <td style="padding:0px; text-align: right;" id="">
                      <input type="text" class="form-control" id="ps_bpay" disabled="disabled" style="font-size: 13px; text-align: right;height: 100%; padding: 1px;" placeholder="0.00">
                          <input type="hidden" class="form-control" id="ps_bpay_hid" disabled="disabled">
                        </td>

                    </tr>

                    <tr>

                      <td style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">De Minimis</td>
                      <td style="padding:0px 5px 0px 0px;text-align: right;" id="ps_dmm_ytd"></td>
                      <td colspan="2" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;"></td>

                    </tr>


                    <tbody style="display: ;" id="psview_dmms_div" colspan="4">
                    </tbody>

                    <tr>

                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;color: #fff">i</td>

                    </tr>

                    <tr>

                      <td style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Premium</td>

                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_premiumtotal_ytd">0.00</td>

                      <td style="padding:0px;text-align: center;">0.00</td>

                      <td style="padding:0px; text-align: right;" id="">
                      <input type="text" class="form-control" id="ps_premiumtotal" disabled="disabled" style="font-size: 13px; text-align: right;height: 100%; padding: 1px;" placeholder="0.00">
                          <input type="hidden" class="form-control" id="ps_premiumtotal_hid" disabled="disabled">
                        </td>

                    </tr>

                    <tr>

                      <td style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Overtime</td>

                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_ottotal_ytd">0.00</td>

                      <td style="padding:0px;text-align: center;">0.00</td>

                      <td style="padding:0px; text-align: right;" id="">
                      <input type="text" class="form-control" id="ps_ottotal" disabled="disabled" style="font-size: 13px; text-align: right;height: 100%; padding: 1px;" placeholder="0.00">
                          <input type="hidden" class="form-control" id="ps_ottotal_hid" disabled="disabled">
                        </td>

                    </tr>

                    <tr>

                      <td style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Night Differential</td>

                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_ndtotal_ytd">0.00</td>

                      <td style="padding:0px;text-align: center;">0.00</td>

                      <td style="padding:0px; text-align: right;" id="">
                        <input type="text" class="form-control" id="ps_ndtotal" disabled="disabled" style="font-size: 13px; text-align: right;height: 100%; padding: 1px;" placeholder="0.00">
                          <input type="hidden" class="form-control" id="ps_ndtotal_hid" disabled="disabled">

                      </td>

                    </tr>

                    <tr>
                      <td style=" padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">OT Night Differential</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_ndottotal_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;">0.00</td>
                      <td style="padding:0px; text-align: right;" id="">
                      <input type="text" class="form-control" id="ps_ndottotal" disabled="disabled" style="font-size: 13px; text-align: right;height: 100%; padding: 1px;" placeholder="0.00">
                          <input type="hidden" class="form-control" id="ps_ndottotal_hid" disabled="disabled">
                        </td>
                    </tr>


                    <tr>
                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;color: #fff">i</td>
                    </tr>

                    <tr style="background: #efefef;">
                      <td style="vertical-align: middle; padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Offset</td>
                      <td style="vertical-align: middle;padding:0px 5px 0px 0px; text-align: right;" id="ps_offsetytd">0.00</td>
                      <td style="vertical-align: middle;padding:0px;text-align: center;">
                        
                        <div class="col-md-12 col-sm-12  form-group has-feedback" style="padding: 0px; margin: 0px;">
                      <input type="text" class="form-control" id="offsethrs" placeholder="0.00" style="text-align: center;font-size: 11px; margin: 0px; padding: 0px; height: 18px !important;">
                      <input type="hidden" id="offsethrs_hid">
                      <span id="offsetbtn" class="fa fa-check form-control-feedback right" aria-hidden="true" style="cursor: help;margin-top: 8px !important;font-size: 13px !important; line-height: 0px !important;border-left: 0px !important;right: 3px !important; color: green;" title="Put approved offset hrs and re-process"></span>
                    </div>

                      </td>
                      <td style="vertical-align: middle;padding:0px 5px 0px 0px; text-align: right;" id="ps_offset">0.00</td>
                    </tr>


                    <tr>

                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;color: #fff">i</td>

                    </tr>

                    <tr>

                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Paid Leaves</td>

                    </tr>

                    <tr>

                      <td style="padding:0px;font-size: 12px;padding-left: 10px;">Personal</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_paid_vl_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;">0.00</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_paid_vl">0.00</td>
                    </tr>



                    <tr>

                      <td style="padding:0px;font-size: 12px;padding-left: 10px;">Medical</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_paid_sl_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;">0.00</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_paid_sl">0.00</td>
                    </tr>



                    <tr>
                      <td style="padding:0px;font-size: 12px;padding-left: 10px;">Birthday</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_paid_bl_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;">0.00</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_paid_bl">0.00</td>
                    </tr>

                  <!--   <tr>

                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;color: #fff">i</td>

                    </tr> -->



                    




                  </tbody>

                   </table>

                 </div>





                 



              </div>



              <!-- end of earning -->



              <div class="col-md-6 col-sm-6 col-xs-12" style="margin-top: 10px;">

              
                <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: right;padding: 0px;">
                <button class="btn btn-warning btn-sm" style="font-size: 8px; color: #fff;" id="btnoverride_deducts"><i class="fa fa-exclamation"></i> OVERRIDE</button>
                <div class="btn-group" id="btnoverride_deduct_savediv" style="display: none;padding: 1px;">
                   <button class="btn btn-success btn-sm" style="font-size: 8px; color: #fff;" id="btnsave_deducts">UPDATE</button>
                    <button class="btn btn-default btn-sm" style="background: gray; font-size: 8px; color: #fff;" id="btncancel_deducts">CANCEL</button>
                </div> </div>

              <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0px;">

                   <table id="" class="table table-bordered" style="width:100%; font-size: 12px;padding: 0px;">

                     <thead><tr>

                  <th colspan="4" style="vertical-align: middle;padding: 0px 0px 0px 0px;text-align: center;"> DEDUCTIONS</th></tr></thead>

                  <thead><tr>

                    <td style="text-align: center;vertical-align: middle;padding: 0px;width: 150px;"></td>

                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;">YTD</td>

                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;">HRS</td>

                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;">AMOUNT</td>

                  </tr></thead>

                  <tbody>

                    <tr>

                      <td style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Income Tax</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_withtax_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;"></td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_withtax">0.00</td>
                    </tr>
                    <!-- <tr>
                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;color: #fff">i</td>
                    </tr> -->
                    <tr>

                      <td style="padding:0px;font-size: 12px;font-weight: ;padding-left: 5px;">Shutdown</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_shutdown_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;" id="ps_hrs_shutdown">0.00</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_shutdown">0.00</td>
                    </tr>
                    <tr>

                      <td style="padding:0px;font-size: 12px;font-weight: ;padding-left: 5px;">Absent/AWOL</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_absent_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;" id="ps_hrs_absent">0.00</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_absent">0.00</td>

                    </tr>

                    <tr>

                      <td style="padding:0px;font-size: 12px;font-weight: ;padding-left: 5px;">Tardiness</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_tardy_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;" id="ps_hrs_tardy">0.00</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_tardy">0.00</td>
                    </tr>

                    <tr>

                      <td style="padding:0px;font-size: 12px;font-weight: ;padding-left: 5px;">Undertime</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_ut_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;" id="ps_hrs_ut">0.00</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_ut">0.00</td>

                    </tr>

                   <!--  <tr>

                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;color: #fff">i</td>

                    </tr> -->

                    <tr>

                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Leaves</td>

                    </tr>

                    <tr>

                      <td style="padding:0px;font-size: 12px;padding-left: 10px;">Vacation</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_deduc_vl_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;">0.00</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;">0.00</td>
                    </tr>

                    <tr>
                      <td style="padding:0px;font-size: 12px;padding-left: 10px;">Medical</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_deduc_sl_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;">0.00</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;">0.00</td>
                    </tr>

                    <tr>
                      <td style="padding:0px;font-size: 12px;padding-left: 10px;">Birthday</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_deduc_bl_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;">0.00</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;">0.00</td>
                    </tr>
<!-- 
                    <tr>

                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;color: #fff">i</td>

                    </tr> -->

                    <tr>

                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Statutory</td>

                    </tr>

                    <tr>

                      <td style="padding:0px;font-size: 12px;padding-left: 10px;">SSS</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_stat_ss_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;"></td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_stat_ss">0.00</td>
                    </tr>

                    <tr>
                      <td style="padding:0px;font-size: 12px;padding-left: 10px;">Phil-Health</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_stat_ph_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;"></td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_stat_ph">0.00</td>
                    </tr>

                    <tr>
                      <td style="padding:0px;font-size: 12px;padding-left: 10px;">Pag-Ibig</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_stat_pi_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;"></td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_stat_pi">0.00</td>
                    </tr>

<!--                     <tr>

                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;color: #fff">i</td>

                    </tr> -->

                    <tr>

                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Holiday</td>

                    </tr>

                    <tr>

                      <td style="padding:0px;font-size: 12px;padding-left: 10px;">SNWH</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_neg_snwh_ytd">0.00</td>
                      <td style="padding:0px;text-align: center;" id="ps_hrs_neg_snwh">0.00</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_neg_snwh">0.00</td>
                    </tr>


                    <tr id="tr_line_loan" style="display: none;">
                      <td style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Loans</td>
                      <td style="padding:0px 5px 0px 0px;text-align: right;" id="ps_loan_ytd"></td>
                      <td colspan="2" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;"></td>
                    </tr>

                    <tbody style="display: ;" id="psview_loans_div" colspan="4"></tbody>

                    <tr>

                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Adjustment</td>

                    </tr>

                    
                     <tr style="display: none;">
                      
                      <td style="padding:0px 5px 0px 0px; text-align: right;"></td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;"></td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_paid_adjminus">0.00</td>
                    </tr>


                    <tr style="">
                       <td style="padding:0px;font-size: 12px;padding-left: 10px;" id="ps_paid_adjrem"></td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_adj_ytd"></td>
                       <td style="padding:0px 5px 0px 0px; text-align: right;"></td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;" id="ps_paid_adjplus">0.00</td>
                    </tr>

                    <!-- <tbody style="display: ;" id="psview_dmms_div" colspan="4"></tbody> -->
<!-- 
                    <tr>

                      <td colspan="4" style="padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;color: #fff">i</td>

                    </tr> -->

                   



                  </tbody>

                   </table>

                 </div>



                 



            </div>





            <div class="col-md-12 col-sm-12 col-xs-12" style="padding:0px;">
              <div class="col-md-6 col-sm-6 col-xs-12" style="">
              <table class="table">
                <thead><tr>

                    <td style="text-align: center;vertical-align: middle;padding: 0px;width: 150px;"></td>
                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;"></td>
                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;"></td>
                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;"></td>

                  </tr></thead>

                <tbody>

                    <tr style="background: #d4edf1;font-weight: bold;">
                      <td style="vertical-align: middle;padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Total Gross Earnings</td>
                      <td style="vertical-align: middle;padding:0px 5px 0px 0px; text-align: right;" id="total_earns_ytd">0.00</td>
                      <td style="vertical-align: middle;padding:0px;text-align: center;color: #d4edf1;">-</td>
                      <td style="vertical-align: middle;padding:0px 5px 0px 0px; text-align: right;" id="total_earns">0.00</td>
                    </tr>

                </tbody>

              </table>

              </div>

              <div class="col-md-6 col-sm-6 col-xs-12" style="">

              <table class="table">
                <thead><tr>
                    <td style="text-align: center;vertical-align: middle;padding: 0px;width: 150px;"></td>
                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;"></td>
                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;"></td>
                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;"></td>
                  </tr></thead>
                <tbody>
                     <tr style="background: #d4edf1;font-weight: bold;">
                      <td style="vertical-align: middle;padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Total Deductions</td>
                      <td style="vertical-align: middle;padding:0px 5px 0px 0px; text-align: right;" id="total_deductions_ytd">0.00</td>
                      <td style="vertical-align: middle;padding:0px;text-align: center;color: #d4edf1;">-</td>
                      <td style="vertical-align: middle;padding:0px 5px 0px 0px; text-align: right;" id="total_deductions">0.00</td>
                    </tr>
                </tbody>
              </table>
              <table class="table">
                <thead><tr>
                    <td style="text-align: center;vertical-align: middle;padding: 0px;width: 150px;"></td>
                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;"></td>
                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;"></td>
                    <td style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;"></td>
                  </tr></thead>

                <tbody>
                     <tr style="background: #b4dce2;font-weight: bold;font-size: 16px;">
                      <td style="vertical-align: middle;padding:0px;font-size: 12px;font-weight: bold;padding-left: 5px;">Net Pay</td>
                      <td style="padding:0px 5px 0px 0px; text-align: right;"></td>
                      <td style="padding:0px;text-align: center;color: #b4dce2;">-</td>
                      <td style="vertical-align: middle;padding:0px 5px 0px 0px; text-align: right;" id="total_net">0.00</td>
                    </tr>
                </tbody>
              </table>
              </div>
            </div>


            <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 25px;margin-bottom: 15px;border: 1px solid #dff0f3;border-radius: 5px; padding: 5px;">



              <div class="col-md-6 col-sm-6 col-xs-12" style="">

                <div class="col-md-12 col-sm-12 col-xs-12">

                 <div class="col-md-5 col-sm-6 col-xs-12">

                <label style="margin-bottom: 0px;">Prepared By:</label>

              </div>

               <div class="col-md-7 col-sm-6 col-xs-12">

                <p style="margin-bottom: 0px;">ATOMIT Payroll</p>

              </div>

              </div>

            </div>



            <div class="col-md-6 col-sm-6 col-xs-12" style="">

                <div class="col-md-12 col-sm-12 col-xs-12">

                 <div class="col-md-5 col-sm-6 col-xs-12">

                <label style="margin-bottom: 0px;">Employee Signature:</label>

              </div>

               <div class="col-md-7 col-sm-6 col-xs-12">

                <p style="margin-bottom: 0px;"></p>

              </div>

              </div>

            </div>



          </div>















          <div class="col-md-12 col-sm-12 col-xs-12" style="margin-bottom: 30px; padding: 5px; display: ;">

            <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: center;">

              <p style="font-size: 12px;">BREAKDOWN:</p>

            </div>
            
            <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: right;display: none;">
              <button class="btn btn-success btn-sm" style="font-size: 9px;">UPDATE</button>
            </div>

            <div class="col-md-12 col-sm-12 col-xs-12">

              <table id="" class="table table-bordered" style="width:100%; font-size: 12px;padding: 0px;">

                <thead><tr>

                  <th style="border-top: 1px solid #fff; border-left: 1px solid #fff;"></th>

                  <th colspan="6" style="text-align: center;vertical-align: middle;padding: 0px;">HOURS</th>

                  <th colspan="6" style="text-align: center;vertical-align: middle;padding: 0px;background-color: #d4edf1;">PESO</th>

                </thead>

              <thead>

                        <tr>

                          <th style="text-align: center;vertical-align: middle;padding: 0px;width: 100px;"></th>
                          <th style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;">REGULAR</th>
                          <th style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;">HOLIDAY</th>
                          <th style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;">SNWH</th>
                          <th style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;">RESTDAY</th>
                        <th style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;font-size: 10px;">RD-HOLIDAY</th>

                      <th style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;font-size: 10px;">RD-SNWH</th>
                      <th style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;background: #d4edf1;">REGULAR</th>
                      <th style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;background: #d4edf1;">HOLIDAY</th>
                      <th style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;background: #d4edf1;">SNWH</th>
                      <th style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;background: #d4edf1;">RESTDAY</th>
                      <th style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;background: #d4edf1;font-size: 10px;">RD-HOLIDAY</th>
                      <th style="text-align: center;width: 120px;vertical-align: middle;padding: 0px;background: #d4edf1;font-size: 10px;">RD-SNWH</th>

                        </tr>

                      </thead>

                      <tbody>

                        <tr>

                          <td style="padding:0px 4px 0px 0px;">Premium</td>
                          <td style="padding:0px 4px 0px 0px;">
                            <p style="margin: 0px !important;text-align: right;" id="regHrs_hrs">0.00</p>
                          </td>

                          <td style="padding:0px 4px 0px 0px;">
                            <p style="margin: 0px !important;text-align: right;" id="holRegHrs_phrs">0.00</p>
                          </td>

                          <td style="padding:0px 4px 0px 0px;">
                            <p style="margin: 0px !important;text-align: right;" id="snwhRegHrs_phrs">0.00</p>
                          </td>

                          <td style="padding:0px 4px 0px 0px;">
                            <p style="margin: 0px !important;text-align: right;" id="restDayRegHrs_phrs">0.00</p>
                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="restDayHolRegHrs_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="restDaySnwhRegHrs_phrs">0.00</p>

                          </td>



                          <!-- hours -->

                          <td style="background: #f0f8ff;padding:0px;">
                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="RegHrs_p" value="0.00" disabled="disabled">
                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="holRegHrs_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="snwhRegHrs_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="restDayRegHrs_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="restDayHolRegHrs_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="restDaySnwhRegHrs_p" value="0.00" disabled="disabled">

                          </td>

                        </tr>

                        <tr>

                          <td style="padding:0px 4px 0px 0px;">Overtime</td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="regOT_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="holOT_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="snwhOT_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="restDayOT_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="restDayHolOT_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="restDaySnwhOT_phrs">0.00</p>

                          </td>



                          <!-- hours -->

                          <td style="background: #f0f8ff;padding:0px;">

                            <input type="text" style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" value="0.00" id="regOT_p" class="form-control" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input type="text" style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" value="0.00" id="holOT_p" class="form-control" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input type="text" style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" value="0.00" id="snwhOT_p" class="form-control" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input type="text" style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" value="0.00" id="restDayOT_p" class="form-control" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input type="text" style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" value="0.00" id="restDayHolOT_p" class="form-control" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input type="text" style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" value="0.00" id="restDaySnwhOT_p" class="form-control" disabled="disabled">

                          </td>

                        </tr>

                        <tr>

                          <td style="padding:0px 4px 0px 0px;">ND</td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="regND_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="holND_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="snwhND_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="restDayND_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="restDayHolND_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="restDaySnwhND_phrs">0.00</p>

                          </td>



                          <!-- hours -->

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="regND_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="holND_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="snwhND_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="restDayND_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="restDayHolND_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="restDaySnwhND_p" value="0.00" disabled="disabled">

                          </td>

                        </tr>

                        <tr>

                          <td style="padding:0px 4px 0px 0px;">OT-ND</td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="regNDOT_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="holNDOT_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="restDaySnwhNDOT_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="restDayNDOT_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="restDayHolNDOT_phrs">0.00</p>

                          </td>

                          <td style="padding:0px 4px 0px 0px;">

                            <p style="margin: 0px !important;text-align: right;" id="restDaySnwhNDOT_phrs">0.00</p>

                          </td>



                          <!-- hours -->

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="regNDOT_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="holNDOT_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="SnwhNDOT_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="restDayNDOT_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="restDayHolNDOT_p" value="0.00" disabled="disabled">

                          </td>

                          <td style="background: #f0f8ff;padding:0px;">

                            <input style="margin: 0px !important;text-align: right;height: 100%;padding: 1px; margin: 0px;font-size: 13px;" type="text" class="form-control" id="restDaySnwhNDOT_p" value="0.00" disabled="disabled">

                          </td>

                        </tr>

                      </tbody>

            </table>

            </div>

            <div class="col-md-12 col-sm-12 col-xs-12" style="width: 100%;">
              
              <table style="margin-top: 20px;width: 100%;border-collapse: collapse;" width="100">

          <thead>
            <tr style="text-align: center; border: 1px solid gray;">
              <th colspan="" style="font-size: 10px;color: gray; ">STATUTORY</th>
              <th colspan="3" style="font-size: 8px;color: gray; ">EMPLOYEE (EE)</th>
              <th colspan="4" style="font-size: 8px;color: gray; background-color: #d6e5f3;">EMPLOYER (ER) SHARES</th>
              <th style="font-size: 8px;color: gray; background-color: #d4edf1;">GRAND TOTAL</th>
            </tr>
          </thead>

          <thead>
            <tr style="text-align: center; border: 1px solid gray;">
              <th colspan="" style="font-size: 10px;color: gray; font-weight: normal;"></th>
              <th style="font-size: 8px;color: gray; font-weight: normal;">REG</th>
              <th style="font-size: 8px;color: gray; font-weight: normal;">MPF</th>
              <th style="font-size: 8px;color: gray; font-weight: normal;">TOTAL</th>
              <th style="font-size: 8px;color: gray; background-color: #d6e5f3;font-weight: normal;">REG</th>
              <th style="font-size: 8px;color: gray; background-color: #d6e5f3;font-weight: normal;">EC</th>
              <th style="font-size: 8px;color: gray; background-color: #d6e5f3;font-weight: normal;">MPF</th>
              <th style="font-size: 8px;color: gray; background-color: #d6e5f3;font-weight: normal;">TOTAL</th>
              <th style="font-size: 8px;color: gray; background-color: #d4edf1;font-weight: normal;"></th>
            </tr>
          </thead>
          <tbody style="font-size: 10px;border: 1px solid gray;">
            <tr style="border: 1px solid gray;">
              <td style="font-weight: bold; text-align: left;">SSS</td>
              <td style="text-align: right;" id="psview_sss_ee_reg"></td>
              <td style="text-align: right;" id="psview_sss_ee_mpf"></td>
              <td style="text-align: right;border-right: 1px solid gray;" id="psview_sss_ee_total"></td>
              <td style="text-align: right;" id="psview_sss_er_reg"></td>
              <td style="text-align: right;" id="psview_sss_er_ec"></td>
              <td style="text-align: right;" id="psview_sss_er_mpf"></td>
              <td style="text-align: right;border-right: 1px solid gray;" id="psview_sss_er_total"></td>
              <td style="text-align: right;border-right: 1px solid gray;" id="psview_sss_gtotal"></td>
            </tr>
            <tr style="border: 1px solid gray;background-color: #f0f8ff;">
              <td style="font-weight: bold; text-align: left;">YTD</td>
              <td colspan="3" style="font-weight: bold;text-align: right;border-right: 1px solid gray;" id="psview_sss_ytdee"></td>
              <td colspan="4" style="font-weight: bold;text-align: right;border-right: 1px solid gray;" id="psview_sss_ytder"></td>
              <td style="font-weight: bold;text-align: right;border-right: 1px solid gray;" id="psview_sss_ytdgtotal"></td>
            </tr>
          </tbody>
          <tbody style="font-size: 10px;border: 1px solid gray;">
            <tr style="border: 1px solid gray;">
              <td style="font-weight: bold; text-align: left;">Phil-Health</td>
              <td style="text-align: right;" id="psview_curr_ph_ee"></td>
              <td style="text-align: right;">n/a</td>
              <td style="text-align: right;border-right: 1px solid gray;" id="psview_curr_ph_ee_total"></td>
              <td style="text-align: right;" id="psview_curr_ph_er"></td>
              <td style="text-align: right;">n/a</td>
              <td style="text-align: right;">n/a</td>
              <td style="text-align: right;border-right: 1px solid gray;" id="psview_curr_ph_er_total"></td>
              <td style="text-align: right;border-right: 1px solid gray;" id="psview_curr_ph_total"></td>
            </tr>
             <tr style="border: 1px solid gray;background-color: #f0f8ff;">
              <td style="font-weight: bold; text-align: left;">YTD</td>
              <td colspan="3" style="font-weight: bold;text-align: right;border-right: 1px solid gray;" id="psview_curr_ph_eeytd"></td>
              <td colspan="4" style="font-weight: bold;text-align: right;border-right: 1px solid gray;" id="psview_curr_ph_erytd"></td>
              <td style="font-weight: bold;text-align: right;border-right: 1px solid gray;" id="psview_curr_ph_totalytd"></td>
            </tr>
          </tbody>
          <tbody style="font-size: 10px;border: 1px solid gray;">
            <tr style="border: 1px solid gray;">
              <td style="font-weight: bold; text-align: left;">Pag-Ibig</td>
              <td style="text-align: right;" id="psview_curr_pi_ee"></td>
              <td style="text-align: right;">n/a</td>
              <td style="text-align: right;border-right: 1px solid gray;" id="psview_curr_pi_ee_total"></td>
              <td style="text-align: right;" id="psview_curr_pi_er"></td>
              <td style="text-align: right;">n/a</td>
              <td style="text-align: right;">n/a</td>
              <td style="text-align: right;border-right: 1px solid gray;" id="psview_curr_pi_er_total"></td>
              <td style="text-align: right;border-right: 1px solid gray;" id="psview_curr_pi_total"></td>
            </tr>
            <tr style="border: 1px solid gray;background-color: #f0f8ff;">
              <td style="font-weight: bold; text-align: left;">YTD</td>
              <td colspan="3" style="font-weight: bold;text-align: right;border-right: 1px solid gray;" id="psview_curr_pi_eeytd"></td>
              <td colspan="4" style="font-weight: bold;text-align: right;border-right: 1px solid gray;" id="psview_curr_pi_er"></td>
              <td style="font-weight: bold;text-align: right;border-right: 1px solid gray;" id="psview_curr_pi_total"></td>
            </tr>
          </tbody>
        </table>

            </div>



                        <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 15px;">

              <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: right;padding: 0px;">
                <button class="btn btn-warning btn-sm" style="font-size: 8px; color: #fff;" id="btnoverride_allowance"><i class="fa fa-exclamation"></i> OVERRIDE</button>
                <div class="btn-group" id="btnoverride_allowance_savediv" style="display: none;padding: 1px;">
                   <button class="btn btn-success btn-sm" style="font-size: 8px; color: #fff;" id="btnsave_allowance">UPDATE</button>
                    <button class="btn btn-default btn-sm" style="background: gray; font-size: 8px; color: #fff;" id="btncancel_allowance">CANCEL</button>
                </div> </div>

               <table id="" class="table table-bordered" style="width:100%; font-size: 12px;padding: 0px;">

                 <tbody style="">
                    <tr>
                      <td style="width:30%;vertical-align: middle; padding:0px;font-size: 10px;font-weight: bold;padding-left: 5px;">Expense Report Period:</td>
                      <td style="text-align: center;width:20%;vertical-align: middle;font-size: 10px;    padding: 0px;padding-left: 5px;" id="psview_expense_period"></td>
                      <td style="width:30%;vertical-align: middle; padding:0px;font-size: 10px;font-weight: bold;padding-left: 5px;">Total Expense Refunded:</td>
                       <td style="width:20%;vertical-align: middle;font-size: 10px; text-align: center;    padding: 0px;" id="">
                         <input type="text" class="form-control" id="psview_expense_totalrefunded" disabled="disabled" style="font-size: 13px; text-align: center;height: 100%; padding: 1px;" placeholder="0.00">
                          <input type="hidden" class="form-control" id="psview_expense_totalrefunded_hid" disabled="disabled">
                       </td>
                    </tr>
                    <tr>
                      <td style="width:30%;vertical-align: middle; padding:0px;font-size: 10px;font-weight: bold;padding-left: 5px;">Filed On:</td>
                      <td style="text-align: center;width:20%;vertical-align: middle;font-size: 10px;    padding: 0px;padding-left: 5px;" id="psview_expense_filedon"></td>
                      <td style="width:30%;vertical-align: middle; padding:0px;font-size: 10px;font-weight: bold;padding-left: 5px;">Expense Approval Date:</td>
                       <td style="text-align: center;width:20%;vertical-align: middle;font-size: 10px;    padding: 0px;padding-left: 5px;" id="psview_expense_appdate"></td>
                    </tr>
                    <tr>
                      <td style="width:30%;vertical-align: middle; padding:0px;font-size: 10px;font-weight: bold;padding-left: 5px;">Expense for Reimbursement:</td>
                      <td style="width:20%;vertical-align: middle;font-size: 10px;text-align: center;    padding: 0px;padding-left: 5px;" id="psview_expense_totalforreim"></td>
                      <td style="width:30%;vertical-align: middle; padding:0px;background: #b4dce2;font-weight: bold;font-size: 16px;">Net Proceeds:</td>
                       <td style="width:20%;vertical-align: middle;background: #b4dce2;font-weight: bold;font-size: 16px;text-align: right;" id="psview_net_proceeds"></td>
                    </tr>
                  </tbody>

               </table>
              
            </div>



          </div>







           </div>

         </div>

            <!-- end of content -->



          </div>

        </div>

        <div class="modal-footer">

          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

        </div>

      </div>

    </div>

  </div>





<!-- Modal -->
  <div class="modal fade" id="payAdjustment" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Adjustments</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
      
      <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0px; ">
            <div class="col-md-6 col-sm-6 col-xs-6" style=""><h5 style="font-size: 15px;font-weight: bold;">Daily Base <i class="fa fa-question-circle" title="Daily Base will be applied instead of Monthly Base"></i></h5></div>
              <div class="col-md-6 col-sm-6 col-xs-6" style="text-align: right;">
                <label> <input type="checkbox" class="js-switch" id="checkifdailyyes" unchecked /> </label>
              </div>
           </div>

       <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 5px;"><h5 style="font-size: 15px;">Value Adjustments</h5></div>
          <div class="col-md-12 col-sm-12 col-xs-12">
         <!--    <label>Adjustment:</label> -->
           <div class="form-group row">
                       <div class="col-md-12 col-sm-12 col-xs-12" style="margin-bottom: 5px;">
                         <input type="text" class="form-control" placeholder="Description (50 Char)" id="pay_adjust_add_remarks" maxlength="50" style="font-size: 12px;">
                       </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input type="text" class="form-control" placeholder="0.00" id="pay_adjust_add" style="font-size: 12px;">
                           <input type="hidden" class="form-control" placeholder="0.00" id="pay_adjust_add_hid">
                          <!-- <input type="text" class="form-control" placeholder="0.00" id="pay_adjust_add_hidden"> -->
                          <span class="fa fa-question-circle form-control-feedback right" aria-hidden="true" title="Put - sign for negative value"></span>
                        </div>
                      </div>
          </div>

           <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0px; margin-top: 5px;">
            <div class="col-md-6 col-sm-6 col-xs-6" style=""><h5 style="font-size: 15px;">Statutory</h5></div>
              <div class="col-md-6 col-sm-6 col-xs-6" style="text-align: right;">
                <label> <input type="checkbox" class="js-switch" id="checkifstatyes" checked /> </label>
              </div>
           </div>


            <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0px; margin-top: 5px;">
            <div class="col-md-6 col-sm-6 col-xs-6" style=""><h5 style="font-size: 15px;">DMM</h5></div>
              <div class="col-md-6 col-sm-6 col-xs-6" style="text-align: right;">
                <label> <input type="checkbox" class="js-switch" id="checkifdmmyes" checked /> </label>
              </div>
           </div>


           <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0px; margin-top: 5px;">
            <div class="col-md-6 col-sm-6 col-xs-6" style=""><h5 style="font-size: 15px;">Allowance</h5></div>
              <div class="col-md-6 col-sm-6 col-xs-6" style="text-align: right;">
                <label> <input type="checkbox" class="js-switch" id="checkifallowyes" checked /> </label>
              </div>
           </div>

          <div class="col-md-12 col-sm-12 col-xs-12" style="display: none;">
            <label>Deduction:</label>
           <div class="form-group row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input type="text" class="form-control" placeholder="0.00" id="pay_adjust_minus">
                          <!-- <input type="text" class="form-control" placeholder="0.00" id="pay_adjust_minus_hidden"> -->
                          <span class="fa fa-question-circle form-control-feedback right" aria-hidden="true"></span>
                        </div>
                      </div>
          </div>
          
        </div>
        <div class="modal-footer">
    <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: center !important;">
          <button type="button" class="btn btn-success btn-sm" id="process_dtr" style="font-size: 12px;">Process</button>
          <button type="button" class="btn btn-default btn-sm" data-dismiss="modal" style="font-size: 12px;background: gray; color: #fff;">Cancel</button>
          </div>
        </div>
      </div>
    </div>
  </div>





<!-- Modal -->
  <div class="modal fade" id="myModalTaxDetails" role="dialog" style="margin-top:2%;">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="padding: 3px;background: #17a2b8; color: #fff;">
          <h4 class="modal-title" style="font-size: 15px;">Tax Details</h4>
          <button type="button" class="close" data-dismiss="modal" id="closetaxdetailsmodal">&times;</button>
        </div>
        <div class="modal-body">

          <div id="taxdetailsdiv"></div>

          <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: center;">
            <button class="btn btn-success btn-sm" style="font-size: 10px;" id="taxoverridebtn"><i class="fa fa-edit"></i> OVERRIDE</button>
          </div>
        </div>
      </div>

       <div class="col-md-12 col-sm-12 col-xs-12" id="loaderpage_taxdetailsmodal" style="text-align: center;position: absolute;top: 50%; display: none;left: 8%;">
    <img src="../images/Spin-1s-137px.gif" class="ajax-loader">
  </div>
      
    </div>
  </div>



@include('mainscript')

<!-- Custom Theme Scripts -->
<link rel="stylesheet" type="text/css" href="../dropzone2/basic.css?v=000002">
<script src="../dropzone2/dropzone.js?v=000003"></script>

<!-- Custom Theme Scripts -->
    <script src="../js/payroll/paysliptbl.js?v=000213"></script>

@endsection