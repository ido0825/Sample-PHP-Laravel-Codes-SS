<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Database\DatabaseController;
use App\Http\Controllers\Config\ConfigController;
use App\Http\Controllers\DTR\DTRController;
use App\Http\Controllers\Employee\EmployeeController;
use App\Http\Controllers\Employee\EmployeeDetailsController;
use App\Http\Controllers\Employee\EmployeeDMMController;
use App\Http\Controllers\Employee\EmployeeStatutoryController;
use App\Http\Controllers\Employee\EmployeeLeaveController;
use App\Http\Controllers\Employee\EmployeeOverviewController;
use App\Http\Controllers\Employee\EmployeeLoansController;
use App\Http\Controllers\Payroll\PayCalcController;
use App\Http\Controllers\Payroll\PayDetailsController;
use App\Http\Controllers\Payroll\PayslipViewController;
use App\Http\Controllers\SysAd\SysAdController;
use App\Http\Controllers\Payslip\PayslipController;
use App\Http\Controllers\Payslip\PayslipReprocessController;
use App\Http\Controllers\Payslip\PayslipTaxOverrideController;
use App\Http\Controllers\BIR\BIRForm1601Controller;

use App\Http\Controllers\Payroll\PayDetailsProRatedController;
use App\Http\Controllers\Payslip\PayslipTesterController;

use App\Http\Controllers\Payroll\BulkPayDetailsController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/', function () {
    // return view('modules.payroll.calc');
  if (Auth::check()) {
      return view('home');
    }else{
    return redirect('login');
    }
});

Route::get('/home', function () {
    // return view('modules.payroll.calc');
  if (Auth::check()) {
      return view('home');
    }else{
    return redirect('login');
    }
});

Route::get('/dtr_summary', function () {
    // return view('modules.payroll.calc');
  if (Auth::check()) {
       return view('modules.dtrsum.dtr_summary');
    }else{
    return redirect('login');
    }
});




Route::get('payroll', function () {
  if (Auth::check()) {
       return view('modules.payroll.payslip_tbl');
    }else{
    return redirect('login');
    }
    
});

Route::get('reports', function () {
  if (Auth::check()) {
       return view('modules.reports.1601');
    }else{
    return redirect('login');
    }
});


//Config Module
Route::get('con_get_list', ['middleware' => 'auth',ConfigController::class, 'con_get_list']);
Route::post('con_save_con', ['middleware' => 'auth',ConfigController::class, 'con_save_con']);
Route::post('con_get_grpings', ['middleware' => 'auth',ConfigController::class, 'con_get_grpings']);

//Database
Route::get('test_db_conn', ['middleware' => 'auth',DatabaseController::class, 'test_db_conn']);
Route::post('dtr_sum_synch', ['middleware' => 'auth',DatabaseController::class, 'dtr_sum_synch']);
Route::post('get_ip_address', ['middleware' => 'auth',DatabaseController::class, 'get_ip_address']);

//DTR
Route::get('dtr_get_list', ['middleware' => 'auth',DTRController::class, 'dtr_get_list']);
Route::post('uploadDtrCutoff',['middleware' => 'auth',DTRController::class, 'uploadDtrCutoff']);
Route::post('loadup_new_uploadDTR',['middleware' => 'auth',DTRController::class, 'loadup_new_uploadDTR']);
Route::post('update_dtr_hours',['middleware' => 'auth',DTRController::class, 'update_dtr_hours']);

//EMPLOYEE
Route::get('empl_get_list', ['middleware' => 'auth',EmployeeController::class, 'empl_get_list']);
Route::post('save_new_employee', ['middleware' => 'auth',EmployeeController::class, 'save_new_employee']);
Route::get('x_save', ['middleware' => 'auth',EmployeeDetailsController::class, 'x_save']);
Route::post('emp_get_info_details', ['middleware' => 'auth',EmployeeDetailsController::class, 'emp_get_info_details']);
Route::post('emp_details_update', ['middleware' => 'auth',EmployeeDetailsController::class, 'emp_details_update']);

Route::post('emp_get_sal_details', ['middleware' => 'auth',EmployeeDetailsController::class, 'emp_get_sal_details']);
Route::post('emp_save_sal_details', ['middleware' => 'auth',EmployeeDetailsController::class, 'emp_save_sal_details']);




Route::post('dmm_get_listtypes', ['middleware' => 'auth',EmployeeDMMController::class, 'dmm_get_listtypes']);
Route::get('dmm_get_empdmms', ['middleware' => 'auth',EmployeeDMMController::class, 'dmm_get_empdmms']);
Route::post('dmm_save_new', ['middleware' => 'auth',EmployeeDMMController::class, 'dmm_save_new']);
Route::post('dmm_empp_calccurrent', ['middleware' => 'auth',EmployeeDMMController::class, 'dmm_empp_calccurrent']);
Route::post('delete_dmm', ['middleware' => 'auth',EmployeeDMMController::class, 'delete_dmm']);


Route::get('allowance_get_empallow', ['middleware' => 'auth',EmployeeDMMController::class, 'allowance_get_empallow']);
Route::post('allowance_save_new', ['middleware' => 'auth',EmployeeDMMController::class, 'allowance_save_new']);
Route::post('update_allowance_status', ['middleware' => 'auth',EmployeeDMMController::class, 'update_allowance_status']);

Route::post('get_new_calculated_stat', ['middleware' => 'auth',EmployeeStatutoryController::class, 'get_new_calculated_stat']);
Route::post('save_new_calculated_stat', ['middleware' => 'auth',EmployeeStatutoryController::class, 'save_new_calculated_stat']);



Route::post('statutory_get_empcurrent', ['middleware' => 'auth',EmployeeStatutoryController::class, 'statutory_get_empcurrent']);
Route::post('leave_get_leavetypes', ['middleware' => 'auth',EmployeeLeaveController::class, 'leave_get_leavetypes']);
Route::post('overview_get_values', ['middleware' => 'auth',EmployeeOverviewController::class, 'overview_get_values']);
Route::post('get_bou_list', ['middleware' => 'auth',EmployeeController::class, 'get_bou_list']);
Route::post('get_etype_list', ['middleware' => 'auth',EmployeeController::class, 'get_etype_list']);
Route::post('get_departs_list', ['middleware' => 'auth',EmployeeController::class, 'get_departs_list']);


//loans
Route::get('loan_get_emploans', ['middleware' => 'auth',EmployeeLoansController::class, 'loan_get_emploans']);
Route::post('loan_add_new', ['middleware' => 'auth',EmployeeLoansController::class, 'loan_add_new']);
Route::post('loan_emp_updateloan', ['middleware' => 'auth',EmployeeLoansController::class, 'loan_emp_updateloan']);

//PAY
Route::post('get_pay_calc', ['middleware' => 'auth',PayCalcController::class, 'get_pay_calc']);
Route::post('get_pay_calc_regdiv', ['middleware' => 'auth',PayCalcController::class, 'get_pay_calc_regdiv']);
Route::post('processdetailsp', ['middleware' => 'auth',PayDetailsController::class, 'processdetailsp']);
Route::post('get_pay_view', ['middleware' => 'auth',PayslipViewController::class, 'get_pay_view']);
Route::get('ps_pdf_emp', ['middleware' => 'auth',PayslipViewController::class, 'ps_pdf_emp']);
Route::get('getDownload', ['middleware' => 'auth',PayslipController::class, 'getDownload']);

Route::post('processAsProRated', ['middleware' => 'auth',PayDetailsProRatedController::class, 'processAsProRated']);


//bulk
Route::post('bulkprocessdetailsp', ['middleware' => 'auth',BulkPayDetailsController::class, 'bulkprocessdetailsp']);

Route::post('payslip_undo', ['middleware' => 'auth',PayslipController::class, 'payslip_undo']);
Route::get('pre_get_list', ['middleware' => 'auth',PayslipController::class, 'pre_get_list']);
Route::post('payslip_notif', ['middleware' => 'auth',PayslipController::class, 'payslip_notif']);
Route::get('payslip_pdf', ['middleware' => 'auth',PayslipController::class, 'payslip_pdf']);
Route::get('payslip_pdf_creation', ['middleware' => 'auth',PayslipTesterController::class, 'payslip_pdf_creation']);


Route::post('offsetbtn_process', ['middleware' => 'auth',PayslipReprocessController::class, 'offsetbtn_process']);
Route::post('payslip_override_tax', ['middleware' => 'auth',PayslipTaxOverrideController::class, 'payslip_override_tax']);

Route::post('payslip_override_allowance', ['middleware' => 'auth',PayslipTaxOverrideController::class, 'payslip_override_allowance']);
Route::post('payslip_override_earnings', ['middleware' => 'auth',PayslipTaxOverrideController::class, 'payslip_override_earnings']);


Route::get('auto_update', ['middleware' => 'auth',SysAdController::class, 'auto_update']);
Route::get('auto_update_ido', [SysAdController::class, 'auto_update_ido']);

Route::get('auto_update_1', [SysAdController::class, 'auto_update_1']);
Auth::routes();

Route::get('/elist', function () {
   if (Auth::check()) {
    	return view('modules.employee.employee');
    }else{
		return redirect('login');
    }
    
});

Route::get('payslipview', function () {
  if (Auth::check()) {
     return view('modules.payroll.payslip_view');
   }else{
    return redirect('login');
    }

});


Route::get('logout', function () {
	Auth::logout();
	return redirect('/login'); 
});












///bir

Route::get('bir-forms', function(){
  return view('modules.birforms.bir-forms');
});
 
Route::get('bir-form-1601c', function(){ 
  return view('modules.birforms.1601c');
});
