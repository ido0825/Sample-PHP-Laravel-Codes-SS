<?php



namespace App\Http\Controllers\Payslip;



use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use DB;
use DateTime;
use Rap2hpoutre\FastExcel\FastExcel;
use Mail;
use PDF;
use Response;
use Illuminate\Support\Facades\Crypt;

use yajra\Datatables\Datatables;


class PayslipReprocessController extends Controller
{

	public function offsetbtn_process(Request $request){
		try {
			set_time_limit(60000);
		$ardata =  $request->input('arrd');
		
		$checker_data = DB::connection('znergee_cpanel')->table('payroll_cutoff_summary')
							->where('pSummaryID',$ardata[0])
							->first();

			$xdata =  [$checker_data->dtrSummaryID,
				floatval(Crypt::decrypt($checker_data->adjustment_add)),
				'',//2
				$checker_data->adjustment_reason,
				$checker_data->total_e,
				$checker_data->total_d, //5
				$checker_data->net_proceeds,
				$checker_data->allowance,
				$checker_data->total_premium,//8
				$checker_data->total_ot,
				$checker_data->total_nd, //10
				$checker_data->total_ndot,
				$checker_data->semim,
			$checker_data->total_dmm];

				$psum = $checker_data->pSummaryID; // date("YmdHis").'-'.rand(100,9999);

			$empd =  DB::connection('znergee_cpanel')->table('dtr_cutoff_summary')
			->join('indivinfo','dtr_cutoff_summary.empID','=','indivinfo.znergeeID')
					->where('dtr_cutoff_summary.dtrSummaryID', $xdata[0])
					->first();

			$zid = $empd->znergeeID; //'EOQ160408-3243';
			$x = $empd->empnum; //'07051511';//$request->input('xhid');
			$month = (int) $empd->month; // '12'; //$request->input('xhid');
			$cutoff = (int) $empd->cutoff; // '1'; //$request->input('xhid');
			$year = (int) $empd->year; // '2020';//$request->input('xhid');

			$emp_rates = DB::connection('znergee_cpanel')->select('call get_emp_sal(?)',array($x));

			$basicpay = 0; $dailyrate = 0; $hourlyrate = 0; $semim = 0; $hoursperday = 0;
			$total_dmm = 0;
			$total_allow = 0;

			if ($emp_rates != null) {
				foreach ($emp_rates as $sval) {
					$basicpay = floatval(str_replace(',','',Crypt::decrypt($sval->basicPay)));
					$dailyrate = floatval(str_replace(',','',Crypt::decrypt($sval->dailyrate)));
					$hourlyrate = floatval(str_replace(',','',Crypt::decrypt($sval->hourlyrate)));
					$annualrate = floatval(str_replace(',','',Crypt::decrypt($sval->annualrate)));
					$daysperyear = $sval->daysperyear;
					$hrsperday = $sval->hoursperday;
					$semim = floatval($basicpay)/2;
					$hoursperday = $sval->hoursperday;
				}
				

				$total_offset = $hourlyrate*$ardata[1];

				$total_ea = Crypt::decrypt($xdata[13])+Crypt::decrypt($xdata[8])+Crypt::decrypt($xdata[9])+Crypt::decrypt($xdata[10])+Crypt::decrypt($xdata[11])+$total_offset;
				$total_e = ($total_ea+Crypt::decrypt($xdata[12]));
				
				$total_d = Crypt::decrypt($xdata[5]);
				$net_p = $total_e-$total_d;

				$old_allowance = Crypt::decrypt($xdata[7]);
				$net_proceeds = $net_p+$old_allowance;

				

			DB::connection('znergee_cpanel')->table('payroll_cutoff_summary')
			->where('pSummaryID',$psum)
				->update([
					"total_e" => Crypt::encrypt($total_e),
					//"total_d" => Crypt::encrypt($total_d),
					"net_p" => Crypt::encrypt($net_p),
					//"tax" => Crypt::encrypt($withhtax),
					"net_proceeds" => Crypt::encrypt($net_proceeds),
					"offset_hrs" => $ardata[1]
				]);


				$off_checker = DB::connection('znergee_cpanel')->table('payroll_cutoff_adjustments')->where('mainID',$psum)->get();

				if (count($off_checker)) {
					DB::connection('znergee_cpanel')->table('payroll_cutoff_adjustments')
					->where("mainID",$psum)
					->update([
						"offset" => Crypt::encrypt($total_offset)
					]);
				}else{
					DB::connection('znergee_cpanel')->table('payroll_cutoff_adjustments')
					->insert([
						"mainID" => $psum,
						"offset" => Crypt::encrypt($total_offset)
					]);
				}
				



				

				$indi = 2;
			}else{
				$indi = 1; //no sal details
			}	

			echo json_encode($indi);

			// dd($psno,$basicpay,$semim,$dailyrate,$hourlyrate,$total_dmm,$total_premium,$total_ot,$total_nd,$total_ndot,$deducs, $statutorys,$negleaves,$total_e,$total_d,$net_p);

		} catch (Exception $e) {
			
		}
	}




























}