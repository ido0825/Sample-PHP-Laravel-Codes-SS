<?php



namespace App\Http\Controllers\DTR;



use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use DB;
use DateTime;
use Rap2hpoutre\FastExcel\FastExcel;

use yajra\Datatables\Datatables;


class DTRController extends Controller
{

	public function dtr_get_list(Request $request){

		try {

			$emonth = $request->input('emonth');
			$ecutoff = $request->input('ecutoff');
			$eyear = $request->input('eyear');
			$ebou = $request->input('ebou');

			if ($ebou == "All"){
				if (Auth::user()->bouAccess == 1){
					$datas = DB::connection('znergee_cpanel')->table('dtr_cutoff_summary')
					->join('indivinfo','dtr_cutoff_summary.empID','=','indivinfo.znergeeID')
					->where('dtr_cutoff_summary.month',$emonth)
					->where('dtr_cutoff_summary.cutoff',$ecutoff)
					->where('dtr_cutoff_summary.year',$eyear)
					->where('indivinfo.isActive',1)
					->get();
				}else{
					$bouarr = [];
						$boulist = DB::connection('znergee_cpanel')->table('user_to_bou')
						->where('user_to_bou.userID',Auth::user()->id)->get();

						if (count($boulist)) {
							foreach ($boulist as $bou) {
								array_push($bouarr, $bou->bouID);
							}
						}

						$datas = DB::connection('znergee_cpanel')->table('dtr_cutoff_summary')
						->join('indivinfo','dtr_cutoff_summary.empID','=','indivinfo.znergeeID')
						->where('dtr_cutoff_summary.month',$emonth)
						->where('dtr_cutoff_summary.cutoff',$ecutoff)
						->where('dtr_cutoff_summary.year',$eyear)
						->whereIn('indivinfo.bouID',$bouarr)
						->where('indivinfo.isActive',1)
						->get();
				}
			}else{

				$datas = DB::connection('znergee_cpanel')->table('dtr_cutoff_summary')
			->join('indivinfo','dtr_cutoff_summary.empID','=','indivinfo.znergeeID')
			->where('dtr_cutoff_summary.month',$emonth)
			->where('dtr_cutoff_summary.cutoff',$ecutoff)
			->where('dtr_cutoff_summary.year',$eyear)
			->where('indivinfo.bouID',$ebou)
			->where('indivinfo.isActive',1)
			->get();

			}


			



			return Datatables::of($datas)

			->addColumn('ctr',function($datas){
				return '';
            })

            ->addColumn('edit_dtr',function($datas){
            	if ($datas->hasPS == 0){
				return '<a class="edit_dtr" href="#" id="'.$datas->rowID.'" style="font-weight: bold;" data-toggle="modal" data-target="#editdtr_modal"><i class="fa fa-edit"></i></a>';            		
			}else{
				return '<a class="undo_ps" href="#" id="'.$datas->rowID.'" style="color:red;font-weight: bold;"><i class="fa fa-undo"></i></a>';
			}

            })
            ->addColumn('process_dtr',function($datas){
            	if ($datas->hasPS == 0){
            		return '<a class="process_dtr" href="#" id="'.$datas->dtrSummaryID.'" style="color: green; font-weight: bold;"> <img src="../images/process.png" class="processdtrtop" width="25" height="25"></a>';
            	}else{
            		return '<a class="reprocess_dtr" href="#" id="'.$datas->dtrSummaryID.'" style="color: red; font-weight: bold;"> <img src="../images/reprocess.jpg" class="processdtrtop" width="25" height="25"></a>';
            	}
				
            })

            ->addColumn('name',function($datas){

            	if ($datas->hasPS == 0) {

            		return '<label style="font-weight:bold;color: black;">'.$datas->lastName.', '.$datas->firstName.'</label>';
            		// return '<a class="hrefemp_process" href="#" id="'.$datas->znergeeID.'" style="color: red;text-decoration: underline;">'.$datas->lastName.', '.$datas->firstName.'</a>';

            	}else{
            		return '<label style="font-weight:bold;color: #377cb8;">'.$datas->lastName.', '.$datas->firstName.'</label>';
            		// return '<a class="hrefemp" data-toggle="modal" data-target="#myModal" href="" id="'.$datas->empnum.'" style="color: #17a2b8;text-decoration: underline;">'.$datas->lastName.', '.$datas->firstName.'</a>';

            	}

				

            })

            ->rawColumns(['name','edit_dtr','process_dtr','ctr'])

			->make(true);



		} catch (Exception $e) {

			

		}

	}


public function uploadDtrCutoff(Request $request){
	$file = $request->file('file');
	$file_name =  $request->file('file')->getClientOriginalName();
	$ext =  $request->file('file')->getClientOriginalExtension();
	$filename = $file_name;//.'.'.$ext;
	$path = 'dtrs/';//.'/';
	return $file->move($path,$filename);
}

public function loadup_new_uploadDTR(Request $request){
	 $colls = (new FastExcel)->import('dtrs/'.$request->input('filex'));

	 $errorlist = [];
	 foreach ($colls as $key) {

	 	$checker = DB::connection('znergee_cpanel')->table('dtr_cutoff_summary')->where('empID',$key['EMPLOYEE'])
	 				->where('month',$key['MONTH'])
	 				->where('cutoff',$key['CUTOFF'])
	 				->where('year',$key['YEAR'])
	 				->where('hasPS',1)
	 				->get();

	 	if (count($checker)) {
	 		array_push($errorlist, $key['EMPLOYEE']);
	 	}else{
	 		$checker2 = DB::connection('znergee_cpanel')->table('dtr_cutoff_summary')
	 				->where('empID',$key['EMPLOYEE'])
	 				->where('month',$key['MONTH'])
	 				->where('cutoff',$key['CUTOFF'])
	 				->where('year',$key['YEAR'])
	 				->get();

	 		if (count($checker2)) {
	 			
	 			DB::connection('znergee_cpanel')->table('dtr_cutoff_summary')
	 				->where('empID',$key['EMPLOYEE'])
	 				->where('month',$key['MONTH'])
	 				->where('cutoff',$key['CUTOFF'])
	 				->where('year',$key['YEAR'])
	 				->update([
	 					'billable' => $key['BILLABLE'],
						'regHrs' => $key['REG HRS'],
						'regND' => $key['REG ND'],
						'regOT' => $key['REG OT'],
						'regNDOT' => $key['OT ND'],
						'restDayRegHrs' => $key['RD WORKED'],
						'restDayND' => $key['RD ND'],
						'restDayOT' => $key['RD OT'],
						'restDayNDOT' => $key['RD ND OT'],
						'holRegHrs' => $key['HOL WORKED'],
						'holND' => $key['HOL ND'],
						'holOT' => $key['HOL OT'],
						'holNDOT' => $key['HOL ND OT'],
						'snwhRegHrs' => $key['SNWH WORKED'],
						'snwhND' => $key['SNWH ND'],
						'snwhOT' => $key['SNWH OT'],
						'snwhNDOT' => $key['SNWH ND OT'],
						'restDayHolRegHrs' => $key['RD HOL WORKED'],
						'restDayHolND' => $key['RD HOL ND'],
						'restDayHolOT' => $key['RD HOL OT'],
						'restDayHolNDOT' => $key['RD HOL ND OT'],
						'restDaySnwhRegHrs' => $key['RD SNWH WORKED'],
						'restDaySnwhND' => $key['RD SNWH ND'],
						'restDaySnwhOT' => $key['RD SNWH OT'],
						'restDaySnwhNDOT' => $key['RD SNWH ND OT'],
						'slLeave' => 0,
						'vlLeave' => 0,
						'blLeave' => 0,
						'shutdown' => $key['SHUTDOWN'],
						'tardy' => $key['TARDY'],
						'absent' => $key['ABSENT'],
						'ut' => $key['UT'],
						'neg_snwh' => 0
	 				]);


	 		}else{

	 			$rowID = $key['EMPLOYEE'].date("-ymd-").rand(100,9999);

	 			DB::connection('znergee_cpanel')->select('call insert_to_pre(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',array(
					$rowID,$key['EMPLOYEE'],$key['MONTH'],$key['CUTOFF'],$key['YEAR'],$key['BILLABLE'],$key['REG HRS'],$key['REG ND'],$key['REG OT'],$key['OT ND'],$key['RD WORKED'],$key['RD ND'],$key['RD OT'],
					$key['RD ND OT'],$key['HOL WORKED'],$key['HOL ND'],$key['HOL OT'],$key['HOL ND OT'],$key['SNWH WORKED'],$key['SNWH ND'],$key['SNWH OT'],$key['SNWH ND OT'],$key['RD HOL WORKED'],$key['RD HOL ND'],$key['RD HOL OT'],$key['RD HOL ND OT'],$key['RD SNWH WORKED'],$key['RD SNWH ND'],$key['RD SNWH OT'],$key['RD SNWH ND OT'],0,0,0,$key['SHUTDOWN'],$key['TARDY'],$key['ABSENT'],$key['UT'],0,date("Y-m-d H:i:s")
				));


	 		}


	 		
	 	}

	 	//$key['slLeave']
					//$key['vlLeave']
					//$key['blLeave']
					//$key['neg_snwh']

	 }

	 echo json_encode($errorlist);
}




public function update_dtr_hours(Request $request){
	$dtrrowID = $request->input('x');
	$arrData = $request->input('arrData');

	DB::connection('znergee_cpanel')->table('dtr_cutoff_summary')
	 				->where('rowID',$dtrrowID)
	 				->update([
						'regHrs' => $arrData[0],
						'regND' => $arrData[1],
						'regOT' => $arrData[2],
						'regNDOT' => $arrData[3],
						'restDayRegHrs' => $arrData[4],
						'restDayND' => $arrData[5],
						'restDayOT' => $arrData[6],
						'restDayNDOT' => $arrData[7],
						'holRegHrs' => $arrData[8],
						'holND' => $arrData[9],
						'holOT' => $arrData[10],
						'holNDOT' => $arrData[11],
						'snwhRegHrs' => $arrData[12],
						'snwhND' => $arrData[13],
						'snwhOT' => $arrData[14],
						'snwhNDOT' => $arrData[15],
						'restDayHolRegHrs' => $arrData[16],
						'restDayHolND' => $arrData[17],
						'restDayHolOT' => $arrData[18],
						'restDayHolNDOT' => $arrData[19],
						'restDaySnwhRegHrs' => $arrData[20],
						'restDaySnwhND' => $arrData[21],
						'restDaySnwhOT' => $arrData[22],
						'restDaySnwhNDOT' => $arrData[23],
						'shutdown' => $arrData[24],
						'tardy' => $arrData[25],
						'absent' => $arrData[26],
						'ut' => $arrData[27],
						'neg_snwh' => $arrData[28],
						'slLeave' => $arrData[29],
						'vlLeave' => $arrData[30],
						'blLeave' => $arrData[31]
	 				]);

	 	echo json_encode(1);
}


//end class

}