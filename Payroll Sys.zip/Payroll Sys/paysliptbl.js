

 $(function () {

get_bou_list();


   $('#offsetbtn').click(function(e){
    var offsethrs = $('#offsethrs').val();
    var offset_psid = $('#psid').val();
    var arrd = [$('#psid').val(),$('#offsethrs').val()];
    offsetbtn_process(arrd);
      //  alert("Something went wrong. Please try again.");
      });


var dnow = new Date();
    var m = dnow.getMonth()+1;
    var y = dnow.getFullYear();
    var dd = dnow.getDate();
    $('#emonth').val(m);
    $('#eyear').val(y);

    if (dd < 16) {
     $('#ecutoff').val(1);
     mm = m-1;
     $('#emonth').val(mm);
    }else{
     $('#ecutoff').val(0);
    }


$('#closetaxdetailsmodal').click(function(e){
   $('#myModalTaxDetails').modal('hide');
   $('#myModal').modal('show');
 });

$('#taxoverridebtn').click(function(e){


   var r = confirm("OVERRIDING INCOME TAX WILL LOCK PAYSLIP. YOU NEED TO UNDO PAYSLIP IF VARIANCE PERSISTS. PLS CLICK OK TO CONTINUE.");
          if (r == true) {
               document.getElementById("loaderpage_taxdetailsmodal").style.display = "";
              document.getElementById("myModalTaxDetails").style.opacity = "0.5"; 
            payslip_override_tax($('#psid').val(),$('#newtaxvalue_hid').val());
          }else{

          }

   
 });


 $('#myModalTaxDetails').on('hidden.bs.modal', function () {
    
    document.getElementById("loaderpage_taxdetailsmodal").style.display = "none";
    document.getElementById("myModalTaxDetails").style.opacity = "";
    $('#taxdetailsdiv').html();

    });






$(this).on('click', '#payrolltbl .undo_ps', function (){

        // $('#ps_name').text(this.text);
        // $('#ps_empnum').val(this.id);
        var tr = $(this).closest('tr');
        var row = payrolltbl.row(tr);
        var d = row.data(); 
        // get_pay_view(this.id,d['psID']);

        var r = confirm("Undo payslip?");
          if (r == true) {
            payslip_undo(this.id,d['psID']);
          } 

      });
  
  var paysliptoprocess = "";

   $(this).on('click', '#payrolltbl .processicon', function (){
      paysliptoprocess = this.id;
    });


   $('#payAdjustment').on('hidden.bs.modal', function () {
    paysliptoprocess = "";
    $('#pay_adjust_add').val("");
     $('#pay_adjust_add_hid').val("");
    $('#pay_adjust_minus').val("");
    $('#psid').val("");
    $('#eid').val("");

    $('#checkifstatyes').trigger('checked');
$('#checkifdmmyes').trigger('checked');
$('#checkifallowyes').trigger('checked');

      // pre_get_list();
    });

    $('#myModal').on('hidden.bs.modal', function () {

  document.getElementById("taxoverridebtn").disabled = false;
  document.getElementById("offsethrs").disabled = false;
 document.getElementById("offsetbtn").style.display = "";

    cleardatas();
      // pre_get_list();
    });



$('#pay_adjust_add').click(function(e){
    $('#pay_adjust_add').val("");
    $('#pay_adjust_add_hid').val("");
});


$('#pay_adjust_add').change(function(e){
  var a = Number($('#pay_adjust_add').val());
  var aa = Number(a.toFixed(2));
  $('#pay_adjust_add').val(aa.toLocaleString('us', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
});

$('#pay_adjust_add').keyup(function(e){
    $('#pay_adjust_add_hid').val($('#pay_adjust_add').val());
});


$('#psview_expense_totalrefunded').click(function(e){
    $('#psview_expense_totalrefunded').val("");
    $('#psview_expense_totalrefunded_hid').val("");
});

$('#psview_expense_totalrefunded').change(function(e){
  var a = Number($('#psview_expense_totalrefunded').val());
  var aa = Number(a.toFixed(2));
  $('#psview_expense_totalrefunded').val(aa.toLocaleString('us', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
});

$('#psview_expense_totalrefunded').keyup(function(e){
    $('#psview_expense_totalrefunded_hid').val($('#psview_expense_totalrefunded').val());
});



$('#ps_premiumtotal').click(function(e){
    $('#ps_premiumtotal').val("");
    $('#ps_premiumtotal_hid').val("");
});

$('#ps_premiumtotal').change(function(e){
  var a = Number($('#ps_premiumtotal').val());
  var aa = Number(a.toFixed(2));
  $('#ps_premiumtotal').val(aa.toLocaleString('us', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
});

$('#ps_premiumtotal').keyup(function(e){
    $('#ps_premiumtotal_hid').val($('#ps_premiumtotal').val());
});


$('#ps_bpay').click(function(e){
    $('#ps_bpay').val("");
    $('#ps_bpay_hid').val("");
});

$('#ps_bpay').change(function(e){
  var a = Number($('#ps_bpay').val());
  var aa = Number(a.toFixed(2));
  $('#ps_bpay').val(aa.toLocaleString('us', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
});

$('#ps_bpay').keyup(function(e){
    $('#ps_bpay_hid').val($('#ps_bpay').val());
});



$('#ps_ottotal').click(function(e){
    $('#ps_ottotal').val("");
    $('#ps_ottotal_hid').val("");
});

$('#ps_ottotal').change(function(e){
  var a = Number($('#ps_ottotal').val());
  var aa = Number(a.toFixed(2));
  $('#ps_ottotal').val(aa.toLocaleString('us', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
});

$('#ps_ottotal').keyup(function(e){ $('#ps_ottotal_hid').val($('#ps_ottotal').val()); });



$('#ps_ndtotal').click(function(e){
    $('#ps_ndtotal').val("");
    $('#ps_ndtotal_hid').val("");
});

$('#ps_ndtotal').change(function(e){
  var a = Number($('#ps_ndtotal').val());
  var aa = Number(a.toFixed(2));
  $('#ps_ndtotal').val(aa.toLocaleString('us', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
});

$('#ps_ndtotal').keyup(function(e){ $('#ps_ndtotal_hid').val($('#ps_ndtotal').val()); });



$('#ps_ndottotal').click(function(e){
    $('#ps_ndottotal').val("");
    $('#ps_ndottotal_hid').val("");
});

$('#ps_ndottotal').change(function(e){
  var a = Number($('#ps_ndottotal').val());
  var aa = Number(a.toFixed(2));
  $('#ps_ndottotal').val(aa.toLocaleString('us', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
});

$('#ps_ndottotal').keyup(function(e){ $('#ps_ndottotal_hid').val($('#ps_ndottotal').val()); });


$('#btnoverride_allowance').click(function(e){
   document.getElementById("psview_expense_totalrefunded").disabled = false;
   document.getElementById("btnoverride_allowance_savediv").style.display = "";
   document.getElementById("btnoverride_allowance").style.display = "none";
  $('#psview_expense_totalrefunded').focus();
  $('#psview_expense_totalrefunded').trigger('click');
});

$('#btncancel_allowance').click(function(e){
   document.getElementById("psview_expense_totalrefunded").disabled = true;
   document.getElementById("btnoverride_allowance_savediv").style.display = "none";
   document.getElementById("btnoverride_allowance").style.display = "";
  $('#psview_expense_totalrefunded').val($('#psview_expense_totalforreim').text());
  $('#psview_expense_totalrefunded_hid').val("");
});


$('#btnsave_allowance').click(function(e){
  var valto = parseFloat($('#psview_expense_totalrefunded_hid').val());

  if (valto < 0 || $('#psview_expense_totalrefunded').val() == "" ) {
    alert("Please input value.");
  }else{
  
  var r = confirm("Your are now officially overriding this payslip Project Expense. Click OK to proceed:");
          if (r == true) {
              payslip_override_allowance($('#psid').val(),$('#psview_expense_totalrefunded_hid').val());
          }

  }

});


$('#btnoverride_earnings').click(function(e){
   document.getElementById("ps_bpay").disabled = false;
   document.getElementById("ps_premiumtotal").disabled = false;
   document.getElementById("ps_ottotal").disabled = false;
   document.getElementById("ps_ndtotal").disabled = false;
   document.getElementById("ps_ndottotal").disabled = false;

   document.getElementById("btnoverride_earning_savediv").style.display = "";
   document.getElementById("btnoverride_earnings").style.display = "none";
});


$('#btncancel_earnings').click(function(e){

  document.getElementById("ps_bpay").disabled = true;
   document.getElementById("ps_premiumtotal").disabled = true;
   document.getElementById("ps_ottotal").disabled = true;
   document.getElementById("ps_ndtotal").disabled = true;
   document.getElementById("ps_ndottotal").disabled = true;

   document.getElementById("btnoverride_earning_savediv").style.display = "";
   document.getElementById("btnoverride_earnings").style.display = "none";
   get_pay_view($('#ps_eid').text(),$('#psid').val());
});



$('#btnsave_earnings').click(function(e){
  var basepay = parseFloat($('#ps_bpay_hid').val());
  var premium = parseFloat($('#ps_premiumtotal_hid').val());
  var otedit = parseFloat($('#ps_ottotal_hid').val());
  var ndedit = parseFloat($('#ps_ndtotal_hid').val());
  var ndotedit = parseFloat($('#ps_ndottotal_hid').val());

  if ($('#ps_bpay').val() == "" || $('#ps_premiumtotal').val() == "" || $('#ps_ottotal').val() == "" ||
    $('#ps_ndtotal').val() == "" || $('#ps_ndottotal').val() == "" ) {
    alert("Please input value. (input 0 instead of blank)");
  }else{
  var r = confirm("Your are now officially overriding this payslip Earnings. Click OK to proceed:");
          if (r == true) {
              payslip_override_earnings($('#psid').val(),basepay,premium,otedit,ndedit,ndotedit);
          }
  }

});





$('#offsethrs').change(function(e){
  var a = Number($('#offsethrs').val());
  var aa = Number(a.toFixed(2));
  $('#offsethrs').val(aa.toLocaleString('us', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
});

$('#offsethrs').keyup(function(e){
    $('#offsethrs_hid').val($('#offsethrs').val());
});

$('#offsethrs').click(function(e){
  $('#offsethrs').val("");
    $('#offsethrs_hid').val("");
});


$(this).on('click', '#myModalTaxDetails #newtaxvalue', function (){ //$('#newtaxvalue').click(function(e){
    $('#newtaxvalue').val("");
    $('#newtaxvalue_hid').val("");
});

$(this).on('change', '#myModalTaxDetails #newtaxvalue', function (){
  var a = Number($('#newtaxvalue').val());
  var aa = Number(a.toFixed(2));
  $('#newtaxvalue').val(aa.toLocaleString('us', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
});

$(this).on('keyup', '#myModalTaxDetails #newtaxvalue', function (){
    $('#newtaxvalue_hid').val($('#newtaxvalue').val());
});


$('#dl_ps_pdf').click(function(e){

  window.open('/getDownload?'+$('input[name=_token]').val()+'='+$('input[name=_token]').val()+'&&psid='+$('#psid').val()+'&&eid='+$('#eid').val()+'');
//    payslip_pdf($('#psid').val(),$('#eid').val());
});




   $('#processdtrtop').click(function(e){
    bulkprocessdetailsp();
});



   $('#pay_adjust_minus').click(function(e){
    $('#pay_adjust_minus').val("");
});

   $('#pay_adjust_minus').change(function(e){
  var a = Number($('#pay_adjust_minus').val());
  var aa = Number(a.toFixed(2));
  $('#pay_adjust_minus').val(aa.toLocaleString('us', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
});


 $('#process_dtr').click(function(e){
var isstat = 0;
var isdmmyes = 0;
var isallowanceyes = 0;
var isdaily = 0;


  if ($('#checkifdailyyes').prop('checked') == true) { isdaily = 1;  }else{ isdaily = 0; }
  if ($('#checkifstatyes').prop('checked') == true) { isstat = 1;  }else{ isstat = 0; }
  if ($('#checkifdmmyes').prop('checked') == true) { isdmmyes = 1;  }else{ isdmmyes = 0; }
  if ($('#checkifallowyes').prop('checked') == true) { isallowanceyes = 1;  }else{ isallowanceyes = 0; }

    var processdatax = [
    paysliptoprocess,
    $('#pay_adjust_add_hid').val(),
    $('#pay_adjust_minus').val(),
    $('#pay_adjust_add_remarks').val(),
    isstat,
    isdmmyes,
    isallowanceyes,
    isdaily
    ];

    // console.log(isstat);

    if (parseFloat(processdatax[1]) >= 0 && processdatax == "") {
        $('#pay_adjust_add_remarks').focus();
    }else{
      if (isdaily == 1) {
          processAsProRated(processdatax);
          console.log("run pro rated");
      }else{ processdetailsp(processdatax); }
      
    }
    
});

   // $(this).on('click', '#payrolltbl .process_dtr', function (){
   //    console.log(this.id);
   //    processdetailsp(this.id);
   //  });


   $(this).on('click', '#payrolltbl .hrefemp', function (){
    var tr = $(this).closest('tr');
        var row = payrolltbl.row(tr);
        var d = row.data(); 

        $('#psid').val(d['psID']);
        $('#eid').val(this.id);

   
      emaltosend = d['emailAdd'];
      $('#payslip_email_pdf').text(d['emailAdd']);
      get_pay_view(this.id,d['psID']);
    });

   $('#searchdtr').click(function(e){
     
        pre_get_list();
      });


      $('#ps_btnemail_it').click(function(e){
        document.getElementById("div_ps_email_confirm_div").style.display = "";
      });
      $('#payslip_email_cancel').click(function(e){
        document.getElementById("div_ps_email_confirm_div").style.display = "none";
      });


var emaltosend = '';
      $('#ps_confirm_email').click(function(e){
        
        var r = confirm("Your are now officially sending this payslip to "+emaltosend+". Any accidental sending is unrecoverable.");
          if (r == true) {
            document.getElementById("div_ps_email_confirm_div").style.display = "none";
            payslip_notif($('#psid').val(),$('#eid').val(),$('#payslip_email_pdf').text());
           
          }

      });






})







var payrolltbl;
   function pre_get_list(){
  payrolltbl = $('#payrolltbl').DataTable({
        processing: true,
        serverSide: false,
         paging: true,
          searching: false,
          ordering: false,
          info: true,
          destroy: true,
          autoWidth: false,
          bLengthChange: false,
         ajax: {
    "url": 'pre_get_list',
    "data": {
        "emonth": $('#emonth').val(),
        "ecutoff": $('#ecutoff').val(),
        "eyear": $('#eyear').val(),
        "ebou": $('#ebou').val(),
    }
    },  
        columns: [
        
        // {data: 'ctr', className: 'trxcenter'},
        {data: 'process_dtr', className: 'trxcenter'},
        {data: 'name', className: 'trxcenter'},
        {data: 'cutoff', className: 'trxcenter'},
        {data: 'paydate', className: 'trxcenter'},
        {data: 'pslipnum', className: 'trxcenter'},
        {data: 'emailAdd', className: 'trxcenter'},
        {data: 'psID', className: 'trxcenter'},
            ]
            ,
             "columnDefs": [ {
              "searchable": false,
              "orderable": false,
              "bSortable":false,
              "bVisible": false,
              "targets": [5,6]

          }]//,



});



    // payrolltbl.on( 'order.dt search.dt', function () {

    //     payrolltbl.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {

    //         cell.innerHTML = i+1;

    //     } );

    // } ).draw();

}



    function bulkprocessdetailsp(){

        $.ajax({
           type: "POST",
           url: "bulkprocessdetailsp",
   dataType:"json",
           data: {
            '_token': $('input[name=_token]').val(),
            "emonth": $('#emonth').val(),
        "ecutoff": $('#ecutoff').val(),
        "eyear": $('#eyear').val(),
        "ebou": $('#ebou').val(),
        },
           cache: false,
  beforeSend: function(){   },
  success: function(msg){ 
    
    if (msg[1] == 1) {
      alert("Please ");
    }


    },
  error:function (xhr, ajaxOptions, thrownError){  console.log(thrownError); }    
      });
    }

function processdetailsp(x){

        $.ajax({
           type: "POST",
           url: "processdetailsp",
   dataType:"json",
           data: {
            '_token': $('input[name=_token]').val(),
            'x' : x
        },
           cache: false,
  beforeSend: function(){  
    $('#payAdjustment').modal('hide');
      document.getElementById("loaderpage").style.display = "";
      document.getElementById("mainpagediv").style.opacity = "0.5"; 
},
  success: function(msg){ 
    $('#pay_adjust_add_remarks').val("");

// $('#checkifstatyes').attrr('click');
// $('#checkifdmmyes').attrr('click');
// $('#checkifallowyes').attrr('click');



    if (msg == 1) {
      alert("No Salary Detected!");

      document.getElementById("loaderpage").style.display = "none";
    document.getElementById("mainpagediv").style.opacity = "";
    }else{
      document.getElementById("loaderpage").style.display = "none";
    document.getElementById("mainpagediv").style.opacity = "";

    pre_get_list();
    }
   
    
    },
  error:function (xhr, ajaxOptions, thrownError){  console.log(thrownError);

      $('#pay_adjust_add_remarks').val("");
       }    

      });
    }

function processAsProRated(x){

        $.ajax({
           type: "POST",
           url: "processAsProRated",
   dataType:"json",
           data: {
            '_token': $('input[name=_token]').val(),
            'x' : x
        },
           cache: false,
  beforeSend: function(){  
    $('#payAdjustment').modal('hide');
      document.getElementById("loaderpage").style.display = "";
      document.getElementById("mainpagediv").style.opacity = "0.5"; 
},
  success: function(msg){ 
    $('#pay_adjust_add_remarks').val("");

// $('#checkifstatyes').trigger('click');
// $('#checkifdmmyes').trigger('click');
// $('#checkifallowyes').trigger('click');



    if (msg == 1) {
      alert("No Salary Detected!");

      document.getElementById("loaderpage").style.display = "none";
    document.getElementById("mainpagediv").style.opacity = "";
    }else{
      document.getElementById("loaderpage").style.display = "none";
    document.getElementById("mainpagediv").style.opacity = "";

    pre_get_list();
    }
   
    
    },
  error:function (xhr, ajaxOptions, thrownError){  console.log(thrownError);

      $('#pay_adjust_add_remarks').val("");
       }    

      });
    }


    function payslip_notif(x,y,z){

        $.ajax({
           type: "POST",
           url: "payslip_notif",
   dataType:"json",
           data: {
            '_token': $('input[name=_token]').val(),
            'psid' : x,
            'eid' : y,
            'emaltosend': z
        },
           cache: false,
  beforeSend: function(){   },
  success: function(msg){ 
    
    
     if (msg == 1) {
       emaltosend = '';
      alert('Sent');
    }else{
      alert('Not sent. No details!');
    }
    },
  error:function (xhr, ajaxOptions, thrownError){  console.log(thrownError); }    
      });
    }


        function payslip_override_tax(x,y){

        $.ajax({
           type: "POST",
           url: "payslip_override_tax",
   dataType:"json",
           data: {
            '_token': $('input[name=_token]').val(),
            'psid' : x,
            'newtaxvalue' : y
        },
           cache: false,
  beforeSend: function(){   },
  success: function(msg){ 
     $('#myModalTaxDetails').modal('hide');
    $('#myModal').modal('hide');
    cleardatas();
    },
  error:function (xhr, ajaxOptions, thrownError){  console.log(thrownError); }    
      });
    }


     function payslip_override_allowance(x,y){

        $.ajax({
           type: "POST",
           url: "payslip_override_allowance",
   dataType:"json",
           data: {
            '_token': $('input[name=_token]').val(),
            'psid' : x,
            'newallvalue' : y
        },
           cache: false,
  beforeSend: function(){   },
  success: function(msg){ 

    $('#myModal').modal('hide');
    cleardatas();
    },
  error:function (xhr, ajaxOptions, thrownError){  console.log(thrownError); }    
      });
    }


    function payslip_override_earnings(x,basepay,premium,otedit,ndedit,ndotedit){

        $.ajax({
           type: "POST",
           url: "payslip_override_earnings",
   dataType:"json",
           data: {
            '_token': $('input[name=_token]').val(),
            'psid' : x,
            'basepay' : basepay,
            'premium' : premium,
            'otedit' : otedit,
            'ndedit' : ndedit,
            'ndotedit' : ndotedit
        },
           cache: false,
  beforeSend: function(){ 
   document.getElementById("btnoverride_earning_savediv").style.display = "none";
   document.getElementById("btnoverride_earnings").style.display = "";
     },
  success: function(msg){ 
    cleardatas();
    get_pay_view($('#ps_eid').text(),x);
    },
  error:function (xhr, ajaxOptions, thrownError){  console.log(thrownError); }    
      });
    }



function offsetbtn_process(x){
$.ajax({
           type: "POST",
           url: "offsetbtn_process",
   dataType:"json",
           data: {
            '_token': $('input[name=_token]').val(),
            'arrd' : x,
        },
           cache: false,
  beforeSend: function(){  },
  success: function(msg){ 
     
     if (msg == 1) {
      alert("No Salary Detected!");
    }else{
      $('#myModal').modal('hide');
      pre_get_list();
    }

    },
  error:function (xhr, ajaxOptions, thrownError){  console.log(thrownError); }    

      });
    }









function get_pay_view(x,y){

        $.ajax({
           type: "POST",
           url: "get_pay_view",
   dataType:"json",
           data: {
            '_token': $('input[name=_token]').val(),
            'eid': x,
            'psid': y
        },

           cache: false,

  beforeSend: function(){ 

    $('#ps_eid').text(x);
    document.getElementById("ps_btnemail_it").disabled = true;
    document.getElementById("dl_ps_pdf").disabled = true;
     },

  success: function(msg){ 

if (msg[13] == 1) {
  document.getElementById("tr_line_loan").style.display = "";
}else{
   document.getElementById("tr_line_loan").style.display = "none";
}
$('#psview_dmms_div').html(msg[3]);
$('#psview_loans_div').html(msg[12]);


$('#ps_psno').text(msg[0][0]['payslipNo']);

$('#ps_bpay').val(msg[0][0]['semim']);
$('#ps_bpay_hid').val(msg[0][0]['hid_semim']);

$('#ps_paid_vl').text(msg[0][0]['paidvl']);
$('#ps_paid_sl').text(msg[0][0]['paidsl']);
$('#ps_paid_bl').text(msg[0][0]['paidbl']);
//$('#psview_expense_totalrefunded').text(msg[0][0]['allowance']);
$('#psview_expense_totalforreim').text(msg[0][0]['allowance']);
$('#psview_expense_totalrefunded').val(msg[0][0]['allowance']);


$('#psview_net_proceeds').text(msg[0][0]['net_proceeds']);
$('#ps_dmm_all').text(msg[0][0]['total_dmm']);
$('#ps_premiumtotal').val(msg[0][0]['total_premium']);
$('#ps_premiumtotal_hid').val(msg[0][0]['hid_total_premium']);
$('#ps_ottotal').val(msg[0][0]['total_ot']);
$('#ps_ottotal_hid').val(msg[0][0]['hid_total_ot']);
$('#ps_ndtotal').val(msg[0][0]['total_nd']);
$('#ps_ndtotal_hid').val(msg[0][0]['hid_total_nd']);
$('#ps_ndottotal').val(msg[0][0]['total_ndot']);
$('#ps_ndottotal_hid').val(msg[0][0]['hid_total_ndot']);
$('#total_earns').text(msg[0][0]['total_e']);

$('#ps_shutdown').text(msg[0][0]['shutdown']);
$('#ps_absent').text(msg[0][0]['absent']);
$('#ps_tardy').text(msg[0][0]['tardy']);
$('#ps_ut').text(msg[0][0]['ut']);
$('#ps_neg_snwh').text(msg[0][0]['neg_snwh']);
$('#ps_stat_ss').text(msg[0][0]['sss']);
$('#ps_stat_ph').text(msg[0][0]['philhealth']);
$('#ps_stat_pi').text(msg[0][0]['pagibig']);
$('#total_deductions').text(msg[0][0]['total_d']);
$('#total_net').text(msg[0][0]['net_p']);

$('#ps_period').text(msg[0][0]['period']);
$('#ps_paydate').text(msg[0][0]['paydate']);
$('#psview_expense_period').text(msg[0][0]['paydate']);
$('#psview_expense_filedon').text(msg[0][0]['paydate']);
$('#psview_expense_appdate').text(msg[0][0]['paydate']);


$('#ps_withtax').text(msg[0][0]['tax']);
$('#ps_paid_adjplus').text(msg[0][0]['adjustment_add']);
$('#ps_paid_adjrem').text(msg[0][0]['adjustment_reason']);
$('#ps_offset').text(msg[0][0]['offset']);
$('#offsethrs').val(msg[0][0]['offset_hrs']);
$('#offsethrs_hid').val(msg[0][0]['offset_hrs']);

$('#ps_department').text(msg[2][0]['departmentID']);
$('#ps_tinno').text(msg[2][0]['tinNo']);
$('#ps_ename').text(msg[2][0]['ename']);
$('#ps_jobt').text(msg[2][0]['jobTitle']);

$('#psview_sss_ee_reg').text(msg[4]['curr_tc_ee']);
$('#psview_sss_ee_mpf').text(msg[4]['curr_p_ee']);
$('#psview_sss_ee_total').text(msg[4]['curr_ss_ee']);
$('#psview_sss_er_reg').text(msg[4]['curr_tc_er']);
$('#psview_sss_er_ec').text(msg[4]['curr_ec_er']);
$('#psview_sss_er_mpf').text(msg[4]['curr_p_er']);
$('#psview_sss_er_total').text(msg[4]['curr_ss_er']);
$('#psview_sss_gtotal').text(msg[4]['curr_ss_total']);

// $('#psview_sss_ytdee').text();
// $('#psview_sss_ytder').text();
// $('#psview_sss_ytdgtotal').text();

$('#psview_curr_ph_ee').text(msg[6]['curr_ph_ee']);
$('#psview_curr_ph_ee_total').text(msg[6]['curr_ph_ee']);
$('#psview_curr_ph_er').text(msg[6]['curr_ph_er']);
$('#psview_curr_ph_er_total').text(msg[6]['curr_ph_er']);
$('#psview_curr_ph_total').text(msg[6]['curr_ph_total']);

// $('#psview_curr_ph_eeytd').text(msg[6]['curr_ph_eeytd']);
// $('#psview_curr_ph_erytd').text(msg[6]['curr_ph_erytd']);
// $('#psview_curr_ph_totalytd').text(msg[6]['curr_ph_totalytd']);


$('#psview_curr_pi_ee').text(msg[5]['curr_pi_ee']);
$('#psview_curr_pi_ee_total').text(msg[5]['curr_pi_ee']);
$('#psview_curr_pi_er').text(msg[5]['curr_pi_er']);
$('#psview_curr_pi_er_total').text(msg[5]['curr_pi_er']);
$('#psview_curr_pi_total').text(msg[5]['curr_pi_total']);

$('#ps_bpay_ytd').text(msg[7][0]['ytd_semim']);
$('#ps_dmm_ytd').text(msg[7][0]['ytd_total_dmm']);
$('#ps_premiumtotal_ytd').text(msg[7][0]['ytd_total_premium']);
$('#ps_ottotal_ytd').text(msg[7][0]['ytd_total_ot']);
$('#ps_ndtotal_ytd').text(msg[7][0]['ytd_total_nd']);
$('#ps_ndottotal_ytd').text(msg[7][0]['ytd_total_ndot']);

$('#ps_paid_vl_ytd').text(msg[7][0]['ytd_paidvl']);
$('#ps_paid_sl_ytd').text(msg[7][0]['ytd_paidsl']);
$('#ps_paid_bl_ytd').text(msg[7][0]['ytd_paidbl']);

$('#ps_withtax_ytd').text(msg[7][0]['ytd_tax']);
$('#ps_shutdown_ytd').text(msg[7][0]['ytd_shutdown']);
$('#ps_absent_ytd').text(msg[7][0]['ytd_absent']);
$('#ps_tardy_ytd').text(msg[7][0]['ytd_tardy']);
$('#ps_ut_ytd').text(msg[7][0]['ytd_ut']);

$('#ps_deduc_vl_ytd').text(msg[7][0]['ytd_vl']);
$('#ps_deduc_sl_ytd').text(msg[7][0]['ytd_sl']);
$('#ps_deduc_bl_ytd').text(msg[7][0]['ytd_bl']);

$('#ps_stat_ss_ytd').text(msg[7][0]['ytd_sss']);
$('#ps_stat_ph_ytd').text(msg[7][0]['ytd_philhealth']);
$('#ps_stat_pi_ytd').text(msg[7][0]['ytd_pagibig']);
$('#ps_neg_snwh_ytd').text(msg[7][0]['ytd_neg_snwh']);

$('#ps_adj_ytd').text(msg[7][0]['ytd_adjust']);

$('#total_earns_ytd').text(msg[7][0]['ytd_total_e']);
$('#total_deductions_ytd').text(msg[7][0]['ytd_total_d']);

document.getElementById("ps_btnemail_it").disabled = false;
document.getElementById("dl_ps_pdf").disabled = false;

$('#ps_hrs_shutdown').text(msg[1][0]['shutdown']);
$('#ps_hrs_absent').text(msg[1][0]['absent']);
$('#ps_hrs_tardy').text(msg[1][0]['tardy']);
$('#ps_hrs_ut').text(msg[1][0]['ut']);
$('#ps_hrs_neg_snwh').text(msg[1][0]['neg_snwh']);

$('#psview_sss_ytdee').text(msg[7][0]['ytd_sss']);
$('#psview_curr_ph_eeytd').text(msg[7][0]['ytd_philhealth']);
$('#psview_curr_pi_eeytd').text(msg[7][0]['ytd_pagibig']);



$('#regHrs_hrs').text(msg[1][0]['regHrs']);
$('#holRegHrs_phrs').text(msg[1][0]['holRegHrs']);
$('#snwhRegHrs_phrs').text(msg[1][0]['snwhRegHrs']);
$('#restDayRegHrs_phrs').text(msg[1][0]['restDayRegHrs']);
$('#restDayHolRegHrs_phrs').text(msg[1][0]['restDayHolRegHrs']);
$('#restDaySnwhRegHrs_phrs').text(msg[1][0]['restDaySnwhRegHrs']);


$('#regOT_phrs').text(msg[1][0]['regOT']);
$('#holOT_phrs').text(msg[1][0]['holOT']);
$('#snwhOT_phrs').text(msg[1][0]['snwhOT']);
$('#restDayOT_phrs').text(msg[1][0]['restDayOT']);
$('#restDayHolOT_phrs').text(msg[1][0]['restDayHolOT']);
$('#restDaySnwhOT_phrs').text(msg[1][0]['restDaySnwhOT']);


$('#regND_phrs').text(msg[1][0]['regND']);
$('#holND_phrs').text(msg[1][0]['holND']);
$('#snwhND_phrs').text(msg[1][0]['snwhND']);
$('#restDayND_phrs').text(msg[1][0]['restDayND']);
$('#restDayHolND_phrs').text(msg[1][0]['restDayHolND']);
$('#restDaySnwhND_phrs').text(msg[1][0]['restDaySnwhND']);


$('#regNDOT_phrs').text(msg[1][0]['regNDOT']);
$('#holNDOT_phrs').text(msg[1][0]['holNDOT']);
$('#restDaySnwhNDOT_phrs').text(msg[1][0]['snwhNDOT']);
$('#restDayNDOT_phrs').text(msg[1][0]['restDayNDOT']);
$('#restDayHolNDOT_phrs').text(msg[1][0]['restDayHolNDOT']);
$('#restDaySnwhNDOT_phrs').text(msg[1][0]['restDaySnwhNDOT']);

$('#RegHrs_p').val(msg[11][0]['regHrs']);
$('#holRegHrs_p').val(msg[11][0]['holRegHrs']);
$('#snwhRegHrs_p').val(msg[11][0]['snwhRegHrs']);
$('#restDayRegHrs_p').val(msg[11][0]['restDayRegHrs']);
$('#restDayHolRegHrs_p').val(msg[11][0]['restDayHolRegHrs']);
$('#restDaySnwhRegHrs_p').val(msg[11][0]['restDaySnwhRegHrs']);

$('#regOT_p').val(msg[11][0]['regOT']);
$('#holOT_p').val(msg[11][0]['holOT']);
$('#snwhOT_p').val(msg[11][0]['snwhOT']);
$('#restDayOT_p').val(msg[11][0]['restDayOT']);
$('#restDayHolOT_p').val(msg[11][0]['restDayHolOT']);
$('#restDaySnwhOT_p').val(msg[11][0]['restDaySnwhOT']);


$('#regND_p').val(msg[11][0]['regND']);
$('#holND_p').val(msg[11][0]['holND']);
$('#snwhND_p').val(msg[11][0]['snwhND']);
$('#restDayND_p').val(msg[11][0]['restDayND']);
$('#restDayHolND_p').val(msg[11][0]['restDayHolND']);
$('#restDaySnwhND_p').val(msg[11][0]['restDaySnwhND']);


$('#regNDOT_p').val(msg[11][0]['regNDOT']);
$('#holNDOT_p').val(msg[11][0]['holNDOT']);
$('#SnwhNDOT_p').val(msg[11][0]['snwhNDOT']);
$('#restDayNDOT_p').val(msg[11][0]['restDayNDOT']);
$('#restDayHolNDOT_p').val(msg[11][0]['restDayHolNDOT']);
$('#restDaySnwhNDOT_p').val(msg[11][0]['restDaySnwhNDOT']);


$('#ps_withtax').html(msg[9]);
$('#taxdetailsdiv').html(msg[10]);


if (msg[0][0]['isEdited'] == 1) {
  document.getElementById("taxoverridebtn").disabled = true;
  document.getElementById("offsethrs").disabled = true;
  document.getElementById("offsetbtn").style.display = "none";
}

    },

  error:function (xhr, ajaxOptions, thrownError){  

    

      console.log(thrownError); }    

      });



    }


    function loadup_new_uploadDTR(x){
        $.ajax({
           type: "POST",
           url: "loadup_new_uploadDTR",
   dataType:"json",
           data: {
            '_token': $('input[name=_token]').val(),
            'filex' : x
        },
           cache: false,
  beforeSend: function(){  
    // document.getElementById("dtrsum_synch").disabled = true;
},
  success: function(msg){ 
    
    document.getElementById("loaderpage").style.display = "none";
    document.getElementById("mainpagediv").style.opacity = "";


    },
  error:function (xhr, ajaxOptions, thrownError){  console.log(thrownError); }    

      });


    }




    function get_bou_list(){
        $.ajax({
           type: "POST",
           url: "get_bou_list",
   dataType:"json",
           data: {
            '_token': $('input[name=_token]').val(),
        },
           cache: false,
  beforeSend: function(){  },
  success: function(msg){ 
   $('#ebou').html('<option value="All" selected="selected">ALL</option>');
   $('#ebou').append(msg);



    pre_get_list();
    },
  error:function (xhr, ajaxOptions, thrownError){  
      console.log(thrownError); }    
      });
    }

    
function payslip_undo(rowID,psID){

        $.ajax({
           type: "POST",
           url: "payslip_undo",
   dataType:"json",
           data: {
            '_token': $('input[name=_token]').val(),
            'rowID' : rowID,
            'psID': psID
        },
           cache: false,
  beforeSend: function(){  
      document.getElementById("loaderpage").style.display = "";
      document.getElementById("mainpagediv").style.opacity = "0.5"; 
},
  success: function(msg){ 
   
    document.getElementById("loaderpage").style.display = "none";
    document.getElementById("mainpagediv").style.opacity = "";

    pre_get_list();
    },
  error:function (xhr, ajaxOptions, thrownError){  console.log(thrownError); }    

      });
    }



    function cleardatas(){

document.getElementById("ps_bpay").disabled = true;
   document.getElementById("ps_premiumtotal").disabled = true;
   document.getElementById("ps_ottotal").disabled = true;
   document.getElementById("ps_ndtotal").disabled = true;
   document.getElementById("ps_ndottotal").disabled = true;

      $('#psview_loans_div').html("");
$('#psview_dmms_div').html("");
$('#ps_psno').text("");
$('#ps_bpay').val("0.00");
$('#ps_bpay_hid').val("");
$('#ps_paid_vl').text("0.00");
$('#ps_paid_sl').text("0.00");
$('#ps_paid_bl').text("0.00");
$('#ps_allowance').text("0.00");
$('#ps_dmm_all').text("0.00");
$('#ps_premiumtotal').val("0.00");
$('#ps_premiumtotal_hid').val("0.00");
$('#ps_ottotal').val("0.00");
$('#ps_ottotal_hid').val("0.00");
$('#ps_ndtotal').val("0.00");
$('#ps_ndtotal_hid').val("0.00");
$('#ps_ndottotal').val("0.00");
$('#ps_ndottotal_hid').val("0.00");
$('#total_earns').text("0.00");

$('#ps_shutdown').text("0.00");
$('#ps_absent').text("0.00");
$('#ps_tardy').text("0.00");
$('#ps_ut').text("0.00");
$('#ps_neg_snwh').text("0.00");
$('#ps_stat_ss').text("0.00");
$('#ps_stat_ph').text("0.00");
$('#ps_stat_pi').text("0.00");
$('#total_deductions').text("0.00");
$('#total_net').text("0.00");

$('#ps_period').text("");
$('#ps_paydate').text("");

$('#ps_hrs_shutdown').text("0.00");
$('#ps_hrs_absent').text("0.00");
$('#ps_hrs_tardy').text("0.00");
$('#ps_hrs_ut').text("0.00");
$('#ps_hrs_neg_snwh').text("0.00");
$('#ps_withtax').text("0.00");
$('#ps_paid_adjplus').text("0.00");
$('#ps_paid_adjminus').text("0.00");

$('#ps_department').text("");
$('#ps_tinno').text("");
$('#ps_ename').text("");
$('#ps_jobt').text("");


$('#psview_sss_ee_reg').text("");
$('#psview_sss_ee_mpf').text("");
$('#psview_sss_ee_total').text("");
$('#psview_sss_er_reg').text("");
$('#psview_sss_er_ec').text("");
$('#psview_sss_er_mpf').text("");
$('#psview_sss_er_total').text("");
$('#psview_sss_gtotal').text("");

// $('#psview_sss_ytdee').text();
// $('#psview_sss_ytder').text();
// $('#psview_sss_ytdgtotal').text();

$('#psview_curr_ph_ee').text("");
$('#psview_curr_ph_ee_total').text("");
$('#psview_curr_ph_er').text("");
$('#psview_curr_ph_er_total').text("");
$('#psview_curr_ph_total').text("");

// $('#psview_curr_ph_eeytd').text(msg[6]['curr_ph_eeytd']);
// $('#psview_curr_ph_erytd').text(msg[6]['curr_ph_erytd']);
// $('#psview_curr_ph_totalytd').text(msg[6]['curr_ph_totalytd']);

$('#psview_curr_pi_ee').text("");
$('#psview_curr_pi_ee_total').text("");
$('#psview_curr_pi_er').text("");
$('#psview_curr_pi_er_total').text("");
$('#psview_curr_pi_total').text("");



document.getElementById("psview_expense_totalrefunded").disabled = true;
   document.getElementById("btnoverride_allowance_savediv").style.display = "none";
   document.getElementById("btnoverride_allowance").style.display = "";
  $('#psview_expense_totalrefunded_hid').val("");


    }