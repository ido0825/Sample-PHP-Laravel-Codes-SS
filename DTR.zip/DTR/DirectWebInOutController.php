<?php

namespace App\Http\Controllers\MainControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use DB;
use DateTime;

use Rap2hpoutre\FastExcel\FastExcel;
use yajra\Datatables\Datatables;
use Illuminate\Support\Facades\Crypt;

class DirectWebInOutController extends Controller
{

	public function emp_time_in(Request $request){
		date_default_timezone_set("Asia/Manila");
		set_time_limit(4000);

		try {

			if (!empty($_SERVER['HTTP_CLIENT_IP'])){ $ip_address = $_SERVER['HTTP_CLIENT_IP'];}
			# whether ip is from proxy
			elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){ $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];}
			# whether ip is from remote address
			else{ $ip_address = $_SERVER['REMOTE_ADDR']; }

			$ip = $ip_address;
			$num = $request->input('num');
			$pin = $request->input('pin');
			#raw logs timein
			$dd = date("Y-m-d H:i:s");

			$checker = DB::table('employee_master')->where('empNum',$num)->where('pin_',$pin)->first();

			if ($checker != null) {
				# employee listed in master table
				if ($checker->statusID == 0){
					#emp is active

					#get employee shift details
					if (date("Y-m-d") >= date("Y-m-d",strtotime($checker->effectivity))) {
						$shiftcode_ass = $checker->shiftCode;
					}else{
						$shiftcode_ass = $checker->oldshift;
					}

					$shift_details = DB::table('d2p_shifts_tbl')->where('shiftCode',$shiftcode_ass)->first();

					if ($shift_details != null) {
						# shift exist below is details
						$duty = $shiftcode_ass;
						$dutystart = $shift_details->shiftStart;
						$dutyend = $shift_details->shiftEnd;
						$shiftcat = date("A",strtotime($shift_details->shiftStart)).'-'.date("A",strtotime($shift_details->shiftEnd));
						$dutytotal = $shift_details->hrsWork;

						#start to processed

						$last_record = DB::table('d2p_processed_data')
									->where('empnum',$num)
									->whereDate('dated',date("Y-m-d",strtotime("-1 day",strtotime($dd) )))
									->orderBy('d2p_processed_data.rowID','DESC')
									->first();

						$latest_record = DB::table('d2p_processed_data')
									->where('empnum',$num)
									->whereDate('dated',date("Y-m-d",strtotime($dd)) )
									->orderBy('d2p_processed_data.rowID','DESC')
									->first();

						if ($last_record == null && $latest_record == null) {
							# new record
							if ($duty == "NA3" || $duty == "NAD3") {
								#3 am check for na3 or nad3
								if (date("H",strtotime($dd)) < 3) {
									$datedas = date("Y-m-d",strtotime("-1 day",strtotime($dd) ));
								}else{ $datedas = date("Y-m-d",strtotime($dd)); }
							}else{ $datedas = date("Y-m-d",strtotime($dd)); }

							DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 1"]);
							$catexit = 1;

						}elseif ($latest_record != null) {
							# todays data exist
							if ($latest_record->timein != null) {
							$expected_out = date("Y-m-d H:i:s",strtotime("+".$dutytotal." hour",strtotime($latest_record->timein)));

								if ($dd < $expected_out){
									#below expected out ignore in
								DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 2"]);
								$catexit = 0;
								$lastrowID = $latest_record->rowID;

								}else{
									#out of expected duty
									if ($latest_record->timeout != null) {
										# consider 2 hrs gap
										$_mins = (strtotime($dd) - strtotime($latest_record->timeout)) / 60;
										$gap_hrs = round((round($_mins,2)/60),2);
										if ($gap_hrs < 2) {
											# ignore in
									DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 3"]);
									$catexit = 0;
									$lastrowID = $latest_record->rowID;

										}else{
										#new in more than 2 hrs gap
								if ($duty == "NA3" || $duty == "NAD3") {
									#3 am check for na3 or nad3
									if (date("H",strtotime($dd)) < 3) {
									$datedas = date("Y-m-d",strtotime("-1 day",strtotime($dd) ));
									}else{ $datedas = date("Y-m-d",strtotime($dd)); }
								}else{ $datedas = date("Y-m-d",strtotime($dd)); }

									DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 4"]);
									$catexit = 1;

										}
									}else{
										#new record
								if ($duty == "NA3" || $duty == "NAD3") {
									#3 am check for na3 or nad3
									if (date("H",strtotime($dd)) < 3) {
									$datedas = date("Y-m-d",strtotime("-1 day",strtotime($dd) ));
									}else{ $datedas = date("Y-m-d",strtotime($dd)); }
								}else{ $datedas = date("Y-m-d",strtotime($dd)); }

									DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 5"]);
									$catexit = 1;
									}
								}
							#END IF IN TODAY IS RECORDED
							}else{
							#today data in is null with out only
								# consider 2 hrs gap
								$_mins = (strtotime($dd) - strtotime($latest_record->timeout)) / 60;
								$gap_hrs = round((round($_mins,2)/60),2);
								if ($gap_hrs < 2) {
											# ignore in
									DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 6"]);
									$catexit = 2;
									$lastrowID = $latest_record->rowID;
								}else{
										#new in more than 2 hrs gap
								if ($duty == "NA3" || $duty == "NAD3") {
									#3 am check for na3 or nad3
									if (date("H",strtotime($dd)) < 3) {
									$datedas = date("Y-m-d",strtotime("-1 day",strtotime($dd) ));
									}else{ $datedas = date("Y-m-d",strtotime($dd)); }
								}else{ $datedas = date("Y-m-d",strtotime($dd)); }

									DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 7"]);
									$catexit = 1;
								}
							} //end else out data only today
					}else{
						#yesterday data possibility
						if ($last_record->timein != null) {
							# yesterday in
							$expected_out = date("Y-m-d H:i:s",strtotime("+".$dutytotal." hour",strtotime($last_record->timein)));
							if ($dd < $expected_out) {
								#ignore in below expected out
								DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 7"]);
								$catexit = 0;
								$lastrowID = $last_record->rowID;
							}else{
								#check consideration 4 hrs gap
								$consi_gap = date("Y-m-d H:i:s",strtotime("+5 hour",strtotime($expected_out)));
								if ($dd < $consi_gap){
									#ignore in for consideration 4 hrs gap
									DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 8"]);
									$catexit = 0;
									$lastrowID = $last_record->rowID;
								}else{
									#more than 4hrs threshold
									if ($last_record->timeout != null) {
										# consider 2 hrs gap
										$_mins = (strtotime($dd) - strtotime($last_record->timeout)) / 60;
										$gap_hrs = round((round($_mins,2)/60),2);
										if ($gap_hrs < 2) {
											# ignore in
									DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 9"]);
									$catexit = 0;
									$lastrowID = $last_record->rowID;
										}else{
										#new in more than 2 hrs gap
								if ($duty == "NA3" || $duty == "NAD3") {
									#3 am check for na3 or nad3
									if (date("H",strtotime($dd)) < 3) {
									$datedas = date("Y-m-d",strtotime("-1 day",strtotime($dd) ));
									}else{ $datedas = date("Y-m-d",strtotime($dd)); }
								}else{ $datedas = date("Y-m-d",strtotime($dd)); }

									DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 10"]);
									$catexit = 1;

										}
									}else{
									#new in - out of 4hrs threshold and more than 2 hrs gap
									if ($duty == "NA3" || $duty == "NAD3") {
									#3 am check for na3 or nad3
								if (date("H",strtotime($dd)) < 3) {
									$datedas = date("Y-m-d",strtotime("-1 day",strtotime($dd) ));
									}else{ $datedas = date("Y-m-d",strtotime($dd)); }

								}else{ $datedas = date("Y-m-d",strtotime($dd)); }
									
									DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 11"]);
									$catexit = 1;
									}

								}
							}//end else out of consideration gap
						}else{
							#yesterday has no in but out only
							# consider 2 hrs gap
							$_mins = (strtotime($dd) - strtotime($last_record->timeout)) / 60;
							$gap_hrs = round((round($_mins,2)/60),2);
							if ($gap_hrs < 2) {
								# ignore in
						DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 9"]);
						$catexit = 2;
						$lastrowID = $last_record->rowID;
							}else{
							#new in more than 2 hrs gap
								if ($duty == "NA3" || $duty == "NAD3") {
									#3 am check for na3 or nad3
									if (date("H",strtotime($dd)) < 3) {
									$datedas = date("Y-m-d",strtotime("-1 day",strtotime($dd) ));
									}else{ $datedas = date("Y-m-d",strtotime($dd)); }
								}else{ $datedas = date("Y-m-d",strtotime($dd)); }

									DB::table('d2p_logs')->insert(["logs" => $dd." TIME IN:: ".$num." processed 10"]);
									$catexit = 1;

										}
						}
					} //end of else yesterday posibility
					
					if ($catexit == 0) {
						# code for ignore in 
						DB::table('d2p_processed_data')
						->where('rowID',$lastrowID)
						->update([ "lastin" => $dd ]);
						$rawstat = 1;
					}elseif ($catexit == 1) {
						# code for new row of IN data
						DB::table('d2p_processed_data')
						->insert([
							"shiftCode" => $duty,
							"empName" => $checker->Lname.', '.$checker->Fname,
							"dated" => $datedas, "timein"=> $dd,
							"empnum"=> $num ]);
						$rawstat = 1;
					}elseif ($catexit == 2) {
						DB::table('d2p_processed_data')
						->where('rowID',$lastrowID)
						->update([ "timein" => $dd, "timeout" => null, "isChanged" => 1 ]);
						$rawstat = 1;
					}else{
						DB::table('portal_logs')->insert(["empnum" => $request->input('num'), "logs" => "No exit category for IN data of employee: ".$num]);
						$rawstat = 0;
					}

					}else{
						#shiftcode dont exist in shift table
						DB::table('d2p_logs')->insert([
							"logs" => $dd." TIME IN:: ".$num.' emp has no defines shift or shiftcode dont exist'
						]);
					}

				DB::table('d2p_raw_data_dev')
					->insert([
						"dateTime" => $dd,
						"lastName" => $checker->Lname, "firstName" => $checker->Fname, //$names[1],
						"terminalName" => "D2P Online Terminal - IN", "empnum" => $num,
						"sourceID" => 1, "ipAddress" => $ip, "isProcessed" => $rawstat ]);

				$lastdata = DB::table('d2p_raw_data_dev')->where('empnum',$num)->where('sourceID',1)
							->orderby('dateTime','DESC')->first();

					if ($lastdata != null) {
						$last_date = date("m/d/y h:i A",strtotime($lastdata->dateTime));
						if ($lastdata->terminalName == "D2P Online Terminal - IN") { $activity = "[TIME IN]";
						}else{ $activity = "[TIME OUT]"; }
					}else{
						$last_date = ""; $activity = "";
					}

				$msg = [1,$checker->Fname,$activity,$last_date,date("m/d/y h:i A",strtotime($dd))];
				
				echo json_encode($msg);

				}else{
					#emp is not active
					$msg = [2,""];
					echo json_encode($msg);
				}
			}else{
				# employee not listed or wrong credentials
				$msg = [3,$pind];
				echo json_encode($msg);
			}

		} catch (Exception $e) {
			DB::table('portal_logs')->insert(["empnum" => $request->input('num'), "logs" => $e]);
			\Log::info("*** PORTAL ERROR LOGS:: Employee Number: ".$request->input('num')."");
		}
	//end for timein function
	}

public function check_double()
{
	date_default_timezone_set("Asia/Manila");
	set_time_limit(4000);

	try {
		$checker = DB::table('d2p_processed_data')->whereDate('dated','>',date("Y-m-d",strtotime("2020-08-25 00:00:00")))->get();
		$array_ = [];
		$double = [];

		foreach ($checker as $key) {
			if (in_array($key->empnum."-".$key->timein, $array_)) {
				array_push($double, $key->empnum."-".$key->timein);
			}else{
				array_push($array_, $key->empnum."-".$key->timein);
			}
		}

		dd($double);
	} catch (Exception $e) {
		
	}
}
//end of class
}