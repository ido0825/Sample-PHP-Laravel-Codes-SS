<?php

namespace App\Http\Controllers\MainControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use DB;
use DateTime;

use Rap2hpoutre\FastExcel\FastExcel;
use yajra\Datatables\Datatables;
use Illuminate\Support\Facades\Crypt;

class EmployeeScannerController extends Controller
{
	public function employee_scan_decs(){


		$pw = strval('');//values per client
        $serverName = ""; //values per client
		$connectionInfo = array( "Database"=>"", "UID"=>"", "PWD" => $pw);
		$conn = sqlsrv_connect( $serverName, $connectionInfo);

		$sql = "SELECT Fname, Lname, Mname, status, d2p_pin, empnum FROM [dbo].[user] WHERE status = ?";
		$params = array('A');
		$entry_result = sqlsrv_query($conn, $sql, $params);
		$emp_list = null;
		 $ctr = 0;


		if ($entry_result != null) {

			//echo "if";
			while($row = sqlsrv_fetch_array($entry_result, SQLSRV_FETCH_ASSOC)) {

				//dd($row['empNum']);

				if ($row['empnum'] == "" || $row['empnum'] == null) {
					//echo "null";
				}else{
					
					$checker = DB::table('employee_master')
							->where('empNum',$row['empnum'])
							//->where('empName',$row['empname'])
							->get();

					if (count($checker)) {
						//DB::table('employee_master')->update(["decsStat" => $row['status'],"empName" => $row['empname']]);
					}else{
						$ctr++;
						DB::table('employee_master')
						->insert([
							"empNum" => $row['empnum'],
							"Fname" => $row['Fname'],
							"Mname" => $row['Mname'],
							"Lname" => $row['Lname'],
							"decsStat" => $row['status']
						]);
					}

				}
	    		
			}//end of while
		}else{
			echo "null";
		}

		echo $ctr;

	}


public function generate_pin_code(){
	try {
	
	$checker = DB::table('employee_master')
	->get();
	$ctr = 0;

	if (count($checker)) {
		foreach ($checker as $row) {
	
	$length = 5;
	$newpin = sprintf("%0{$length}d", mt_rand(10000, pow(10, $length)-1));
	$pl = strlen($row->pin_);
	if ($pl <= 4) {
		//echo strlen($newpin)."</br>";
		$ctr++;
		
			DB::table('employee_master')
			->where('rowID',$row->rowID)
			->where('empNum',$row->empNum)
			->update([
				"pin" => Crypt::encrypt($newpin),
				"pin_" => $newpin
			]);

	}

		}//foreach end
	}

	echo $ctr;

	} catch (Exception $e) {
		
	}
	

}


	public function decs_pin_code(){
		try {
		
		$pw = strval('');
        $serverName = ""; 
		$connectionInfo = array( "Database"=>"", "UID"=>"", "PWD" => $pw);
		$conn = sqlsrv_connect( $serverName, $connectionInfo);

		$datas = DB::table('employee_master')->get();

		if (count($datas)) {
			$ctr = 0;
			foreach ($datas as $data) {
				$sql = "UPDATE [dbo].[user] SET d2p_pin = ? WHERE empnum = ?";
				$params = array($data->pin_,$data->empNum);
				$stmt = sqlsrv_query($conn, $sql, $params);

				$ctr++;
			}

			echo "Updated : ".$ctr;
		}else{
			echo "No to update.";
		}

		

		} catch (Exception $e) {
			
		}

	}
//end class
}