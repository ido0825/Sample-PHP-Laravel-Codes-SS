<?php

use Illuminate\Support\Facades\Route;



Route::get('generate_report_data',['middleware' => 'auth','uses' =>'MainControllers\ReportTabContoller@generate_report_data']);

Route::get('import_raw_data',['middleware' => 'auth','uses' =>'MainControllers\ReportTabContoller@import_raw_data']);

Route::get('process_raw_data',['middleware' => 'auth','uses' =>'MainControllers\ReportTabContoller@process_raw_data']);

Route::get('conn_decs',['middleware' => 'auth','uses' =>'MainControllers\ReportTabContoller@conn_decs']);



Route::get('jc_to_d2p',['middleware' => 'auth','uses' =>'MainControllers\ScannerController@jc_to_d2p']);


Route::get('en_de_crpt',['middleware' => 'auth','uses' =>'MainControllers\PinMasterController@en_de_crpt']);

Route::get('load_pins_tbl',['middleware' => 'auth','uses' =>'MainControllers\PinMasterController@load_pins_tbl']);

Route::post('indiv_regenerate_pin',['middleware' => 'auth','uses' =>'MainControllers\PinMasterController@indiv_regenerate_pin']);



Route::get('/admin', function () {
    if (Auth::check()) {
    	 return redirect('home'); 
    }else{
		return view('auth.login');
    }
    
});


Route::get('/resetpassword', function () {
    return view('auth.passwords.reset');
});

Route::get('/login', function () {
   // return redirect('/admin'); 
	if (Auth::check()) {
    	 return redirect('home'); 
    }else{
		return redirect('admin'); 
    }
});

Route::get('logout', function () {
	Auth::logout();
	return redirect('/admin'); 
});

Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');

Route::get('/home', function () {
    if (Auth::check()) {
    	 return view('home'); 
    }else{
		return redirect('admin');
    }
    
});

Route::get('/masterpin', function () {
    if (Auth::check()) {
    	 return view('pages.pinmaster'); 
    }else{
		return redirect('admin');
    }
    
});

