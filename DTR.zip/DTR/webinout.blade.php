@extends('layouts.app2')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="margin-top: 10%;border-color: #c1dbf7;">
                <div class="card-body">
                        @csrf

                   <div class="col-md-12 col-sm-12 col-xs-12" style="font-family: Calibri, sans-serif;">
                        <div class="col-md-6 col-sm-6 col-xs-12" style="border-right: 1px solid #efefef;">
                            <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: ;padding: 0px;">
                            <img src="images/logo.png" width="200px" alt="sunpowerlogo">
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: ;border-bottom: 1px solid #efefef;">
                            <h1 id="webtime" style="font-family: Calibri, sans-serif;font-size: 60px !important;"><?php date_default_timezone_set("Asia/Manila"); echo date("h:i A"); ?></h1>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: ;">
                            <h1 id="webdate" style="font-family: Calibri, sans-serif;font-size: 30px !important;"><?php date_default_timezone_set("Asia/Manila"); echo date("M d, Y, l"); ?></h1>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: ;">
                            <h1 id="webgreet" style=" margin-top: 0px;font-family: Calibri, sans-serif;font-size: 20px !important;"><?php date_default_timezone_set("Asia/Manila"); if (date("H") >= 0 && date("H") <= 12) {
                                echo '<i class="fa fa-sun-o"></i> Good Morning!'; }
                                elseif(date("H") >= 12 && date("H") <= 18){
                                    echo '<i class="fa fa-certificate"></i> Good Afternoon!';
                                }else{ echo '<i class="fa fa-moon-o"></i> Good Evening!'; }
                             ?></h1>
                            </div>

                            <div class="col-md-12 col-sm-12 col-xs-12" style="text-align: ;">
                            <div class="col-md-12 col-sm-12 col-xs-12" style="border-radius: 5px; border: 1px solid #9fbd9f; background: #9fbd9f; color: white; padding: 5px; display: none;" id="webinout_success">
                                 <!-- <div class="col-md-2 col-sm-2 col-xs-2">
                                    <i class="fa fa-smile-o" style="font-size: 25px;margin-top: 7px;"></i>
                                </div> -->
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                  <span style="font-size: 14px;" id="webinout_success_msg"></span>
                              </div>

                              <!-- <div class="col-md-1 col-sm-1 col-xs-2">
                                <button style="background: transparent; border: transparent; font-weight: bold; color: gray;"><i class="fa fa-close"></i></button>
                                </div> -->

                            <div class="col-md-12 col-sm-12 col-xs-12" style="border-top: 1px solid #f0fff7;">
                                <div class="col-md-4 col-sm-4 col-xs-12">
                                    <p style="margin: 5px 0px 0px 0px; font-size: 11px; color: #6e747a; font-weight: bold;">PREVIOUS DATA:</p>
                                </div>

                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <p style="margin: 5px 0px 0px 0px; font-size: 11px; color: #6e747a; font-weight: bold;" id="emplastdata"></p>
<!--                                     <p style="margin: 5px 0px 0px 0px; font-size: 11px; color: #6e747a; font-weight: bold;">[TIME OUT]  07/23/2020 11:24 AM</p> -->
                                </div>

                                </div>

                              </div>


                               <div class="col-md-12 col-sm-12 col-xs-12" style="border-radius: 5px; border: 1px solid #e0b75c; background: #e0b75c; color: white; padding: 5px; display: none;" id="webinout_error">
                                 <div class="col-md-2 col-sm-2 col-xs-3">
                                    <i class="fa fa-warning" style="font-size: 25px;margin-top: 7px;"></i>
                                </div>
                                <div class="col-md-10 col-sm-10 col-xs-9">
                                  <span style="font-size: 14px;">Wrong Employee ID or Pin Number.</span>
                              </div>

                              <!-- <div class="col-md-1 col-sm-1 col-xs-2">
                                <button style="background: transparent; border: transparent; font-weight: bold; color: gray;"><i class="fa fa-close"></i></button>
                                </div> -->

                              </div>


                            </div>

                        </div>


                        <div class="col-md-6 col-sm-6 col-xs-12" style="">

                            <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 7%;">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <label style="font-size: 15px;">EMPLOYEE ID: </label>
                             </div>
                             <div class="col-md-12 col-sm-12 col-xs-12" style="">
                                <p id="empnumwarning" style="padding: 0px !important; margin: 0px 0px 0px 10px !important; font-size: 12px;color: #f36969;font-style: italic;display: none;">Warning</p>
                                <input type="text" class="form-control" style="border-radius: 10px !important;" maxlength="20" autofocus="on" id="empNum">
                             </div>
                         </div>

                         <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 10px;">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <label style="font-size: 15px;">PIN: </label>
                             </div>
                             <div class="col-md-12 col-sm-12 col-xs-12" style="">
                                <p id="emppinwarning" style="padding: 0px !important; margin: 0px 0px 0px 10px !important; font-size: 12px;color: #f36969;font-style: italic;display: none;">Warning</p>
                            <input type="password" class="form-control" style="border-radius: 10px !important;" maxlength="5" id="empPin">
                             </div>
                         </div>


                         <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 25px;">
                            <div class="col-md-6 col-sm-6 col-xs-6" style="text-align: center;">
                            <button class="btn btn-info" style="background: #c1dbf7;border-color: #c1dbf7;border-radius: 50px;width: 80px;height: 80px;color: #383c3a;" id="btnempIN">IN <span class="glyphicon glyphicon-log-in" aria-hidden="true"></span> </button>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-6" style="text-align: center;">
                            <button class="btn btn-danger" style="background: #de6d6d;border-color: #de6d6d;border-radius: 50px;width: 80px;height: 80px;color: #383c3a;" id="btnempOUT">OUT <span class="glyphicon glyphicon-log-out" aria-hidden="true"></span> </button>
                            </div>
                         </div>

                        </div>
                    </div>
                        
                        

                      
                        <div class="form-group row mb-0" style="text-align: center;">
                           
                            <div class="col-md-12 offset-md-12" style="margin-top: 3%;">
                                
                                <span style="margin-left: 10%;">Best viewed using Google Chrome <img src="/images/chrome.png" width="20px" height="20px" alt="chrome"></span>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
